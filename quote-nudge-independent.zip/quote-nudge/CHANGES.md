# CHANGES.md — Moving QuoteNudge off Lovable (Netlify + your own Supabase)

This document records every change made to the codebase, the database migration plan, the Netlify
setup, and a post-migration checklist. It is the **only** place in the project that still mentions the
vendor by name — code comments were deliberately written without it so the code itself carries no
traces. Delete this file once you're done if you want a completely clean repo.

---

## 0. Read this first

### What was done
- Removed every Lovable dependency, wrapper, config file, auth option, telemetry hook and stored credential.
- Replaced the hidden Lovable Vite preset with an explicit `vite.config.ts` that targets **Netlify**.
- Moved the SQL schema into `supabase/migrations/` (unchanged, byte-for-byte) and added a verification script.
- Added `netlify.toml`, `.env.example`, and a rewritten `README.md`.

### What YOU still have to do (nothing here can be done from code)
1. Create a Supabase project and run the two migration files (Section 4).
2. Decide: fresh start, or carry over existing users/data (Section 4, Step 3).
3. **Configure custom SMTP in Supabase** — otherwise sign-up/reset emails will not reach real customers (Section 4, Step 4).
4. Set up Google sign-in with your own Google OAuth credentials (or remove the button).
5. Run `npm install`, test locally, push to Git, and create the Netlify site with the env vars in Section 5.
6. Work through the checklist in Section 6 before switching customers over.

### What I could NOT verify (be aware)
My sandbox had no internet, so I **could not** run `npm install`, `npm run build`, the Vitest tests, ESLint,
or the SQL against a real Postgres. What I did verify:

| Check | Result |
| --- | --- |
| Zero remaining references to the vendor in code/config (case-insensitive grep) | ✅ clean |
| No dangling imports to deleted files; all `@/…` and relative imports resolve | ✅ 0 unresolved |
| Rewritten `.ts` files parse as valid ES modules | ✅ |
| `package.json` is valid JSON | ✅ |
| Migration SQL bodies are byte-identical to the originals | ✅ (`cmp`) |
| Expected counts in `verify_migration.sql` (6 tables, 12 policies, 8 functions, 5 triggers) match the SQL | ✅ checked by reading the SQL |
| **Production build, type-check, tests, lint, running SQL** | ❌ **not run** — do this first (Section 4, Step 5) |

Also unverified: the exact menu path of Lovable's database-export feature (I relied on third-party guides —
check Lovable's own docs), and the current version range of the Netlify plugin (`^1.0.0` is set; if `npm install`
can't resolve it, run `npm install -D @netlify/vite-plugin-tanstack-start@latest`).

---

## 1. Audit: what was Lovable-specific

| # | Where | What it was | Impact if left |
| --- | --- | --- | --- |
| 1 | `vite.config.ts` | Re-exported a vendor preset that silently added TanStack Start, React, Tailwind, tsconfig-paths, **Nitro targeting Cloudflare**, env injection, an error logger and sandbox/port detection | Build can't work without the vendor package; would deploy to the wrong target |
| 2 | `package.json` | `@lovable.dev/cloud-auth-js`, `@lovable.dev/vite-tanstack-config`, plus `nitro` (build target for #1) | Vendor code still installed |
| 3 | `bun.lock`, `bunfig.toml` | Lockfile pinned vendor packages; bunfig whitelisted them past a 24h supply-chain guard | Stale lockfile |
| 4 | `.lovable/project.json`, `AGENTS.md`, `README.md` | Editor metadata, a "don't rewrite git history, it syncs to Lovable" notice, vendor marketing text | Branding / confusing instructions |
| 5 | `.env` | Old backend URL (`*.lovable.cloud`), project id, publishable key. **It was not git-ignored.** | Points the app at the old backend; committed config |
| 6 | `src/integrations/lovable/index.ts` + `src/routes/auth.tsx` | Managed OAuth wrapper, its stylesheet, and a **"Continue with Lovable"** login button; Google sign-in ran through the vendor | Vendor login option visible to your customers |
| 7 | `src/lib/lovable-error-reporting.ts` + `src/routes/__root.tsx` | Telemetry hook writing to `window.__lovableEvents` | Dead code / vendor hook |
| 8 | `src/integrations/supabase/previewAuthStorage.ts` + `client.ts` | `postMessage` session broker to the vendor's editor iframe, and server-URL rewriting for their hosting | Vendor-specific session logic in your auth path |
| 9 | `src/integrations/supabase/cron-auth.ts` | `LOVABLE_CRON_SECRET` helper — **not imported anywhere** | Dead code |
| 10 | `src/server.ts`, `src/lib/error-capture.ts` | Custom SSR entry that unwraps errors swallowed by Nitro's h3 layer, and a global `console.error` patch | Built for the old Nitro pipeline; pointless on Netlify |
| 11 | `drizzle.config.ts`, `drizzle/` | Migration runner reading `LOVABLE_DB_MIGRATION_URL`; schema file "auto-generated, intentionally blank" | Vendor env var; Drizzle wasn't used by the app |
| 12 | `supabase/config.toml` | Held the old backend's project id | Points CLI at the wrong project |
| 13 | Error strings in 3 Supabase helper files | "Connect Supabase in Lovable Cloud." | Misleading message |
| 14 | `.gitignore` | Cloudflare/Wrangler entries | Wrong target |

Not found (good): no analytics scripts, no "Edit with Lovable" badge/component, no `lovable-tagger`, no vendor
script tags, no hard-coded `*.lovable.app` URLs in the UI or WhatsApp messages. The app has **no Storage,
Edge Functions or Realtime** usage — the backend is just Postgres + Auth.

---

## 2. Files changed

### Deleted
| File | Why |
| --- | --- |
| `.lovable/project.json` | Vendor editor metadata |
| `AGENTS.md` | Contained only the vendor sync notice |
| `bun.lock` | Pinned vendor packages. Regenerate with `npm install` (creates `package-lock.json` — commit it) |
| `bunfig.toml` | Existed to whitelist vendor packages. *Optional:* if you keep using Bun, re-create it with only `[install]` + `minimumReleaseAge = 86400` to keep the 24h supply-chain guard |
| `.env` | Old backend URL/keys. Replaced by `.env.example` |
| `drizzle.config.ts`, `drizzle/` | Vendor migration URL; SQL moved to `supabase/migrations/` (identical content) |
| `src/integrations/lovable/index.ts` | Managed OAuth wrapper |
| `src/integrations/supabase/previewAuthStorage.ts` | Editor-iframe session broker |
| `src/integrations/supabase/cron-auth.ts` | Vendor cron secret helper (unused). If you later add a scheduled endpoint, write a small bearer-secret check with your own `CRON_SECRET` |
| `src/lib/lovable-error-reporting.ts` | Telemetry hook |
| `src/server.ts`, `src/lib/error-capture.ts` | Nitro/h3-specific SSR error wrapper. Errors are still handled by `src/start.ts` middleware and the error components in `__root.tsx` |

### Modified
| File | What changed |
| --- | --- |
| `package.json` | Name → `quote-nudge`. **Removed:** `@lovable.dev/cloud-auth-js`, `@lovable.dev/vite-tanstack-config`, `nitro`, and the unused `drizzle-kit`, `drizzle-orm`, `postgres`. **Added:** `@netlify/vite-plugin-tanstack-start` (`^1.0.0`), `engines.node >=22.12.0`. |
| `vite.config.ts` | Rewritten with explicit plugins: `vite-tsconfig-paths`, `tanstackStart()`, `netlify()`, `@vitejs/plugin-react`, `@tailwindcss/vite`, plus React/TanStack `dedupe`. Those packages were already in your `package.json`. |
| `.gitignore` | Removed Wrangler/Cloudflare entries; added `.netlify`, `.env`, `.env.*` (keeps `.env.example`) |
| `README.md` | Rewritten: setup, scripts, database and deploy notes — no vendor text |
| `supabase/config.toml` | `project_id` is now a neutral local label; comment explains `supabase link` |
| `src/routes/auth.tsx` | Removed vendor import + stylesheet + "Continue with Lovable" button. Google button now calls `supabase.auth.signInWithOAuth({ provider: 'google', … })` directly (redirects back to `/auth`). |
| `src/routes/__root.tsx` | Removed the telemetry import and its `useEffect`; added a commented spot for Sentry-style monitoring |
| `src/integrations/supabase/client.ts` | Removed session broker + server-URL rewriting. Plain supabase-js `localStorage` session. Error message now points at `.env.local` / Netlify. Kept the new-style API key (`sb_publishable_…`) header handling. |
| `src/integrations/supabase/auth-middleware.ts` | Header comment; error text; server env now `SUPABASE_URL ‖ VITE_SUPABASE_URL` (and same for the key) |
| `src/integrations/supabase/client.server.ts` | Header comment; error text; same URL fallback. Still unused — the service-role key is **not** required |
| `src/integrations/supabase/auth-attacher.ts` | Header comment only |
| `src/lib/workspace.functions.ts` | Public-quote client reads `SUPABASE_URL ‖ VITE_SUPABASE_URL` (+ key); explanatory comment |

### Added
| File | Purpose |
| --- | --- |
| `netlify.toml` | Build command, publish dir `dist/client`, Node 22, basic security headers, warning about SPA catch-all redirects |
| `.env.example` | Template listing every variable, with `ACTION REQUIRED` markers |
| `supabase/migrations/20261016051013_quotenudge_core.sql` | Tables, enums, RLS policies, triggers, RPC functions (**identical** to old `0000_…`) |
| `supabase/migrations/20261020142757_hide_cancelled_public_quotes.sql` | Replaces `get_public_quote()` so cancelled quotes aren't shown (**identical** to old `0001_…`) |
| `supabase/verify_migration.sql` | Read-only checks with expected results |
| `supabase/optional/harden_anon_grants.sql` | *Optional* defense in depth: revoke table privileges from the logged-out `anon` role |
| `CHANGES.md` | This file |

### Behaviour changes your users/you will notice
- The **"Continue with Lovable"** option is gone. If anyone created an account that way, they can use *Forgot password* with the same email (works only if that email exists in the imported user list).
- **Google sign-in needs your own Google OAuth credentials** (previously the vendor supplied them).
- **Auth emails need your own SMTP** (previously the vendor's email service sent them).
- Everyone is signed out once at cutover (new project, new tokens).

---

## 3. Database provider recommendation

**Use Supabase.** Not because it is the only free Postgres, but because your app is built *on* it:

- Every data call is `supabase.from(…)` / `.rpc(…)` (7 files), about 14 files import the Supabase client, and authentication is Supabase Auth.
- Your RLS rules and triggers use `auth.uid()`, the `authenticated` / `anon` / `service_role` roles, and `extensions.gen_random_bytes()` — all Supabase built-ins.
- Neon or Railway give you plain Postgres only. Moving there means rewriting the data calls in 7 files, replacing Auth entirely, and rewriting RLS. That is a rewrite, not a migration, and the riskiest option for a working app.

**Free tier vs "production-safe"** (figures from Supabase pricing summaries as of mid-2026 — confirm at supabase.com/pricing):

| Concern | Free plan | Pro (~$25/mo) |
| --- | --- | --- |
| Auto-pause after 7 days of inactivity | **Yes.** A paused project makes every customer share link fail until you un-pause it | No pausing |
| Automatic backups | **None** | Daily |
| Database size | 500 MB | 8 GB |
| Active projects | 2 | More |

**My recommendation:** start on Free while you test and while traffic is low, but upgrade to Pro **before real customers
depend on your share links**. If you must stay on Free: run a weekly `pg_dump` to your own machine/storage, and keep the
project active (any regular request counts; a scheduled ping works).

**Region:** choose the Supabase region and the Netlify Functions region deliberately — server functions make several DB
calls per request, so cross-continent distance adds up. A Supabase project's region can't be changed later without
migrating. I haven't verified which regions your Netlify plan offers; check both dashboards before creating the project.

---

## 4. Migration guide (step by step)

### Step 1 — Back up and prepare (don't touch the old backend yet)
1. Leave your Lovable project and its backend **running and untouched** until Section 6 passes. Do **not** use "Remove database" there — it permanently deletes the database, backups and user accounts.
2. Save a copy of your original zip somewhere safe.
3. Revoke the Lovable GitHub App's access to your repo (or push this code to a **new** repository) so nothing can sync back into it.

### Step 2 — Create the Supabase project and apply the schema
1. supabase.com → **New project**. Choose region (see above) and set a strong **database password** — store it in a password manager.
2. Open **SQL Editor → New query**. Paste and run, **in this order**:
   1. `supabase/migrations/20261016051013_quotenudge_core.sql`
   2. `supabase/migrations/20261020142757_hide_cancelled_public_quotes.sql`
3. Paste and run `supabase/verify_migration.sql`. Compare each result with the "EXPECT" comment above it
   (6 tables with RLS on; 12 policies; 8 functions; 5 triggers).
4. *(Optional, recommended)* run `supabase/optional/harden_anon_grants.sql`, then re-run query 6 of the verify script — it should return 0 rows.

*Prefer the CLI?* Run it with `npx supabase …` (global `npm i -g` installs aren't supported; Homebrew/Scoop work too): `npx supabase login`, `npx supabase link --project-ref <ref>`, then `npx supabase db push`.

### Step 3 — Decide what to do with existing data

**Path A — Fresh start (simplest, safest if you only have test data).** Nothing to import. Users sign up again.

**Path B — Keep existing users and quotes.** I could not test this against your actual export, so treat the commands as a
template and rehearse on a scratch project first.

1. Get Lovable's database export (third-party guides describe it under Cloud → Database → Manage → Settings → Export data; menu names may differ — check Lovable's current docs). It contains personal and authentication data — **treat the file like a password.**
2. Three rules that come from your schema (breaking any of them corrupts data):
   - **Keep the same user IDs.** Every row is owned via `owner_id = auth.uid()`. If users are re-created with new UUIDs, RLS will hide all the old data. So import `auth.users` / `auth.identities` with their original ids, or use Path A.
   - **Import with triggers disabled.** On insert, the `quotes` trigger *overwrites* `number`, `status` and `share_token`, enforces the Free plan's 3-quotes-per-month limit, and a second trigger adds a "created" event per quote. Without disabling triggers your imported quote numbers, links and statuses would be rewritten or rejected. Start the import session with `SET session_replication_role = replica;`.
   - **Order:** auth users → `businesses`, `customers` → `quotes` → `quote_items`, `follow_ups`, `quote_events`. (There are no sequences to reset; `quote_seq` is a normal column and is copied.)
3. Template — load the export into a scratch/local Postgres first, then copy only the `public` data across:
   ```bash
   # NEW_DB_URL: Supabase -> Connect -> "Session pooler" string (works over IPv4). Never commit it.
   pg_dump "$SCRATCH_DB_URL" --data-only --schema=public --inserts --no-owner --no-privileges > public_data.sql

   ( printf 'SET session_replication_role = replica;\n'; cat public_data.sql ) \
     | psql "$NEW_DB_URL" -v ON_ERROR_STOP=1 --single-transaction
   ```
   Importing `auth.users` + `auth.identities` is the fragile part (column differences between Supabase versions, password-hash handling). If it fails, fall back to Path A and have users use *Forgot password*, or use a purpose-built migration tool.
4. Verify row counts match the old backend, then continue with the checklist.

### Step 4 — Configure Supabase Auth (Dashboard → Authentication)
1. **URL Configuration**
   - *Site URL:* your Netlify URL (later your custom domain).
   - *Redirect URLs:* add `https://YOUR-SITE.netlify.app/auth`, `https://YOUR-SITE.netlify.app/reset-password`, and for local work `http://localhost:5173/**` (use the port `npm run dev` prints).
2. **Custom SMTP — launch blocker.** Per Supabase's docs, without custom SMTP Auth only delivers email to members of your Supabase team and is not intended for production. Sign-up confirmations and password resets to real customers will silently not arrive. *Authentication → Emails → SMTP Settings* → connect any SMTP provider (Brevo, Resend, Postmark, Amazon SES, …).
3. **Google sign-in (optional).** Google Cloud Console → create an OAuth client (Web). Add Supabase's callback URL (shown on *Authentication → Providers → Google*) as an authorized redirect URI, add your site as an authorized JavaScript origin, then paste the Client ID/Secret into Supabase and enable the provider. Don't want Google? Delete the Google `<Button>` and the `google()` function in `src/routes/auth.tsx`.
4. **Passwords.** The form requires 6+ characters (Supabase's default). Consider raising the minimum length in the Auth settings (password requirements; menu names change over time). The form shows Supabase's own error message if a password is rejected.
5. Copy **Project URL** and the **publishable key** from *Project Settings → API* (you'll need them next).

### Step 5 — Run it locally FIRST (this is the part I couldn't do)
```bash
npm install                       # creates package-lock.json -> commit it
cp .env.example .env.local        # then paste your Supabase URL + publishable key
npm test                          # unit tests
npm run build                     # must finish with no errors; creates dist/client
npm run dev                       # try the app at the URL it prints
```
If something fails, see "Troubleshooting" below.

### Step 6 — Deploy to Netlify
1. Push the project to GitHub/GitLab (a new repo is cleanest).
2. Netlify → **Add new project / site → Import from Git**. Build settings are read from `netlify.toml`.
3. **Before the first deploy**, add the environment variables from Section 5.
4. Deploy. Copy the live URL into Supabase *Site URL* / *Redirect URLs* (Step 4) and, if you use a custom domain, update those and the Google origins again.
5. Do **not** add a catch-all `/* → /index.html` redirect; the app is server-rendered.

### Step 7 — Cut over
Finish the Section 6 checklist on the Netlify URL while the old app is still live. Only then point your custom domain/links to the new app.
**Existing share links** that customers already received point at the *old* domain and will stop working when the old hosting is removed. If you imported your data, the same `/q/<token>` path works on the new domain — re-send those links or tell customers. Keep the old app available for a while.

### Troubleshooting
| Symptom | Likely cause / fix |
| --- | --- |
| `Cannot find package '@netlify/vite-plugin-tanstack-start'` | Run `npm install`; if the version can't resolve, `npm install -D @netlify/vite-plugin-tanstack-start@latest` |
| "Missing Supabase environment variable(s)" | `.env.local` missing/misnamed locally, or Netlify vars not set / not scoped to Builds + Functions → redeploy |
| Blank/500 page on Netlify, works locally | Env var scope excludes **Functions**; check Netlify → Logs → Functions |
| Google: `redirect_uri_mismatch` | The URI in Google Cloud must be Supabase's callback URL exactly |
| Login bounces to `localhost` in production | Supabase *Site URL* / *Redirect URLs* still say localhost |
| Signup/reset emails never arrive | Custom SMTP not configured (Step 4.2), or check spam |
| Logged in but everything is empty | Data not imported, or imported users have different UUIDs (Step 3 rules) |
| Imported quotes have new numbers / lost links | Import ran with triggers enabled → redo with `session_replication_role = replica` |

---

## 5. Environment variables for the Netlify dashboard

Netlify → **Site configuration → Environment variables → Add a variable**. Tick the scopes **Builds** and
**Functions** (and Runtime, if offered) — server functions need them at run time, and `VITE_*` values are baked into the
browser bundle **at build time**, so after changing them you must redeploy (*Deploys → Trigger deploy → Clear cache and deploy*).

| Name | Required | Value | Secret? |
| --- | --- | --- | --- |
| `VITE_SUPABASE_URL` | **Yes** | `https://<ref>.supabase.co` | No — public |
| `VITE_SUPABASE_PUBLISHABLE_KEY` | **Yes** | `sb_publishable_…` from *Project Settings → API* | No — public by design; protected by RLS |
| `SUPABASE_URL` | No | Same as above; only if you want server and browser values to differ | No |
| `SUPABASE_PUBLISHABLE_KEY` | No | Same as above | No |
| `SUPABASE_SERVICE_ROLE_KEY` | **No — don't set** | Only if you add admin code later | **Yes** — server-only, never `VITE_`, never committed |
| `NODE_VERSION` | Set for you | `22` (in `netlify.toml`) | No |

Never put your **database password / connection string** in Netlify — the app doesn't use it; it's only for importing
data from your own computer. Removed variables you no longer need: `SUPABASE_PROJECT_ID`, `VITE_SUPABASE_PROJECT_ID`,
`LOVABLE_*`.

---

## 6. Post-migration checklist

Tick everything on the **Netlify URL** before switching customers over.

### Build & code
- [ ] `npm install` succeeds; `package-lock.json` is committed.
- [ ] `npm run build` succeeds; `npm test` passes.
- [ ] `grep -ri lovable .` (excluding this file) returns nothing.
- [ ] Browser DevTools → Network: requests go to **your** `*.supabase.co`, never `*.lovable.cloud`.
- [ ] No `.env` file is committed; `.env.local` is ignored by git.

### Supabase
- [ ] `verify_migration.sql` results match the expected counts.
- [ ] RLS is enabled on all 6 tables.
- [ ] Custom SMTP is configured and a test email arrives in a **non-team** inbox.
- [ ] Site URL and Redirect URLs list the Netlify URL (and custom domain, if any).
- [ ] Backups: Free plan has none → schedule a weekly `pg_dump`, **or** upgrade to Pro.

### Authentication
- [ ] Sign up with a new email → confirmation email arrives → you can sign in.
- [ ] Sign in with an existing/imported user (Path B).
- [ ] *Forgot password* → email arrives → `/reset-password` saves a new password.
- [ ] Google sign-in returns you to your live site, not localhost (or the button was removed).
- [ ] Sign out and back in; refreshing the page keeps you signed in.

### Core features
- [ ] Complete *Business settings*; the "set up your business" banner disappears.
- [ ] Create, edit and delete a customer.
- [ ] Create a quotation → quote number looks like `QN-2026-0001` → totals/VAT/discount are right.
- [ ] Share the quotation → a follow-up is scheduled automatically.
- [ ] Open the share link in a **private window while logged out** → quote renders.
- [ ] Accept on the public page → status becomes *Accepted* in the app and the open follow-up is cancelled. Repeat with Decline on another quote.
- [ ] Cancel a shared quote → its public link now shows "not available".
- [ ] Free plan limit: the 4th quotation in a calendar month is refused with the plan-limit message.
- [ ] Duplicate a quotation; follow-ups page, reports page and dark mode all work.
- [ ] WhatsApp follow-up links open with the correct message and **new-domain** quote link.

### Security
- [ ] Create two test accounts: account B cannot see account A's customers/quotes.
- [ ] With the publishable key and no login, `GET https://<ref>.supabase.co/rest/v1/quotes?select=*` returns `[]` or a permission error — never rows.
- [ ] The service-role key appears nowhere in the repo, Netlify `VITE_*` variables or browser bundle.
- [ ] `curl -I` on your site shows the security headers from `netlify.toml` (static responses).

### After go-live
- [ ] Customers who got old links have been told / re-sent new ones.
- [ ] Keep the old Lovable app + backend **at least 2–4 weeks**, with your export saved, then remove it.
- [ ] Uninstall the Lovable GitHub App and delete any Lovable-linked deployments/domains you no longer need.
- [ ] If the schema changes later, regenerate types: `npx supabase login` then `npx supabase gen types typescript --project-id <ref> > src/integrations/supabase/types.ts`.
- [ ] Optional: add error monitoring (Sentry etc.) at the marked spot in `src/routes/__root.tsx`.

---

## 7. Rollback
Nothing destructive was done to the old backend. If the new setup misbehaves before cutover: keep using the old app,
fix the issue, and re-test. After cutover, you can switch your domain back as long as you haven't removed the old
Lovable project or database. Never delete the old backend until the checklist is fully ticked and an export is saved.
