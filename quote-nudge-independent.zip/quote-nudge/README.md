# QuoteNudge

Create professional quotations, share them with customers by link, and follow up on the ones that
haven't been answered. Built with TanStack Start (React 19, SSR), Tailwind CSS v4 and Supabase
(Postgres + Auth + Row Level Security). Deployed on Netlify.

## Requirements

- Node.js 22.12 or newer
- A Supabase project (free tier is fine to start)
- A Netlify account (for deployment)

## Local development

```sh
npm install
cp .env.example .env.local     # then fill in your Supabase URL + publishable key
npm run dev
```

## Scripts

| Command | What it does |
| --- | --- |
| `npm run dev` | Dev server with Netlify platform emulation |
| `npm run build` | Production build (`dist/client` + server functions) |
| `npm run preview` | Serve the production build locally |
| `npm test` | Run unit tests (Vitest) |
| `npm run lint` / `npm run format` | ESLint / Prettier |

## Database

All SQL lives in `supabase/migrations/` (tables, RLS policies, triggers and RPC functions).
Apply them in filename order, either by pasting each file into the Supabase **SQL Editor** or with
the Supabase CLI (`supabase link --project-ref <ref>` then `supabase db push`).
`supabase/verify_migration.sql` checks that everything was created correctly.

## Environment variables

See `.env.example`. Required: `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY`.

## Deployment

Pushing to the connected Git branch builds and deploys on Netlify using `netlify.toml`.
Set the environment variables in the Netlify dashboard first.
