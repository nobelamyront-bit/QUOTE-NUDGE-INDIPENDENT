-- =====================================================================================
-- QuoteNudge: verify the schema on your NEW Supabase project.
-- Run in Supabase -> SQL Editor AFTER applying both files in supabase/migrations/.
-- Each query lists what a correct result looks like. Read-only: it changes nothing.
-- =====================================================================================

-- 1) Tables + RLS.  EXPECT 6 rows, rls_enabled = true on every row:
--    businesses, customers, follow_ups, quote_events, quote_items, quotes
select c.relname as table_name, c.relrowsecurity as rls_enabled
from pg_class c join pg_namespace n on n.oid = c.relnamespace
where n.nspname = 'public' and c.relkind = 'r'
order by 1;

-- 2) Policy count per table.  EXPECT: businesses 3, customers 1, follow_ups 1,
--    quote_events 2, quote_items 1, quotes 4   (12 policies in total)
select tablename, count(*) as policies
from pg_policies where schemaname = 'public'
group by 1 order by 1;

-- 3) Functions.  EXPECT 8 rows. security_definer must be true for:
--    expire_my_quotes, get_public_quote, quote_items_guard, quotes_after_change,
--    quotes_before_insert, respond_to_quote   (and false for businesses_guard, quotes_before_update)
select p.proname as function_name, p.prosecdef as security_definer
from pg_proc p join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public'
order by 1;

-- 4) Triggers.  EXPECT 5 distinct trigger names:
--    businesses_guard, quote_items_guard, quotes_after_change, quotes_before_insert, quotes_before_update
select event_object_table as table_name, trigger_name,
       string_agg(event_manipulation, ', ' order by event_manipulation) as fires_on
from information_schema.triggers
where trigger_schema = 'public'
group by 1, 2 order by 1, 2;

-- 5) Who may call the public RPCs.  EXPECT get_public_quote and respond_to_quote executable by
--    anon + authenticated, and expire_my_quotes by authenticated only.
select p.proname,
       has_function_privilege('anon', p.oid, 'execute')          as anon_can_run,
       has_function_privilege('authenticated', p.oid, 'execute') as authenticated_can_run
from pg_proc p join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public' and p.proname in ('get_public_quote', 'respond_to_quote', 'expire_my_quotes')
order by 1;

-- 6) (Informational) Table privileges held by the logged-out "anon" role.  RLS already blocks
--    these rows, but you can remove the privileges too: see supabase/optional/harden_anon_grants.sql
--    EXPECT: ideally 0 rows after running that optional script.
select table_name, privilege_type
from information_schema.role_table_grants
where table_schema = 'public' and grantee = 'anon'
order by 1, 2;

-- 7) The pgcrypto function used to generate share tokens.  EXPECT 18 (bytes) -> a 36-character token.
select length(extensions.gen_random_bytes(18)) as random_bytes;
