-- QuoteNudge schema, part 1 of 2: tables, RLS policies, triggers and RPC functions.
-- Moved unchanged from drizzle/migrations/0000_quotenudge_core.sql (only this comment header was added).
-- Safe to run on a brand-new Supabase project (needs the built-in auth schema, the "authenticated" /
-- "anon" / "service_role" roles and the pgcrypto extension in the "extensions" schema, all present by default).

create type public.quote_status as enum ('draft','pending','accepted','rejected','expired','cancelled');

create table public.businesses (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null unique,
  name text not null default '',
  owner_name text not null default '',
  email text,
  phone text,
  business_type text,
  country text not null default 'ZA',
  currency text not null default 'ZAR',
  locale text not null default 'en-ZA',
  timezone text not null default 'Africa/Johannesburg',
  address text,
  logo_url text,
  website text,
  vat_number text,
  registration_number text,
  tax_enabled boolean not null default false,
  tax_rate_bp integer not null default 1500 check (tax_rate_bp between 0 and 10000),
  tax_label text not null default 'VAT',
  validity_days integer not null default 14 check (validity_days between 1 and 365),
  followup_delay_days integer not null default 2 check (followup_delay_days between 1 and 60),
  default_payment_terms text,
  default_terms text,
  plan text not null default 'free' check (plan in ('free','pro')),
  onboarded boolean not null default false,
  quote_seq integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.businesses to authenticated;
grant all on public.businesses to service_role;
alter table public.businesses enable row level security;
create policy "own business select" on public.businesses for select to authenticated using (owner_id = auth.uid());
create policy "own business insert" on public.businesses for insert to authenticated with check (owner_id = auth.uid());
create policy "own business update" on public.businesses for update to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());

-- Prevent users from self-upgrading plan or tampering with sequence
create or replace function public.businesses_guard() returns trigger language plpgsql set search_path = public as $$
begin
  if current_user = 'authenticated' then
    if tg_op = 'INSERT' then
      new.plan := 'free'; new.quote_seq := 0;
    else
      new.plan := old.plan; new.quote_seq := old.quote_seq; new.owner_id := old.owner_id;
    end if;
  end if;
  new.updated_at := now();
  return new;
end $$;
create trigger businesses_guard before insert or update on public.businesses for each row execute function public.businesses_guard();

create table public.customers (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null default auth.uid(),
  name text not null check (char_length(name) between 1 and 200),
  company text,
  email text,
  phone text,
  billing_address text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on public.customers(owner_id);
grant select, insert, update, delete on public.customers to authenticated;
grant all on public.customers to service_role;
alter table public.customers enable row level security;
create policy "own customers" on public.customers for all to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create table public.quotes (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null default auth.uid(),
  customer_id uuid not null references public.customers(id) on delete restrict,
  number text not null,
  title text not null default '',
  intro text,
  status public.quote_status not null default 'draft',
  issue_date date not null default current_date,
  valid_until date not null default (current_date + 14),
  currency text not null default 'ZAR',
  discount_type text not null default 'none' check (discount_type in ('none','percent','fixed')),
  discount_value bigint not null default 0 check (discount_value >= 0),
  tax_enabled boolean not null default false,
  tax_rate_bp integer not null default 0 check (tax_rate_bp between 0 and 10000),
  tax_label text not null default 'VAT',
  fees_cents bigint not null default 0 check (fees_cents >= 0),
  fees_label text,
  subtotal_cents bigint not null default 0,
  discount_cents bigint not null default 0,
  tax_cents bigint not null default 0,
  total_cents bigint not null default 0 check (total_cents >= 0),
  payment_terms text,
  deposit_info text,
  payment_method text,
  terms text,
  customer_notes text,
  internal_notes text,
  share_token text unique,
  link_enabled boolean not null default true,
  finalized_at timestamptz,
  responded_at timestamptz,
  response_message text,
  replaces_id uuid references public.quotes(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (owner_id, number)
);
create index on public.quotes(owner_id, created_at desc);
create index on public.quotes(customer_id);
grant select, insert, update, delete on public.quotes to authenticated;
grant all on public.quotes to service_role;
alter table public.quotes enable row level security;
create policy "own quotes select" on public.quotes for select to authenticated using (owner_id = auth.uid());
create policy "own quotes insert" on public.quotes for insert to authenticated with check (owner_id = auth.uid());
create policy "own quotes update" on public.quotes for update to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "own draft delete" on public.quotes for delete to authenticated using (owner_id = auth.uid() and status = 'draft');

create table public.quote_items (
  id uuid primary key default gen_random_uuid(),
  quote_id uuid not null references public.quotes(id) on delete cascade,
  owner_id uuid not null default auth.uid(),
  position integer not null default 0,
  description text not null check (char_length(description) between 1 and 500),
  quantity numeric(12,3) not null check (quantity > 0),
  unit_price_cents bigint not null check (unit_price_cents >= 0),
  line_total_cents bigint not null check (line_total_cents >= 0)
);
create index on public.quote_items(quote_id);
grant select, insert, update, delete on public.quote_items to authenticated;
grant all on public.quote_items to service_role;
alter table public.quote_items enable row level security;
create policy "own items" on public.quote_items for all to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create table public.follow_ups (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null default auth.uid(),
  quote_id uuid not null references public.quotes(id) on delete cascade,
  customer_id uuid not null references public.customers(id) on delete cascade,
  scheduled_for timestamptz,
  status text not null default 'scheduled' check (status in ('scheduled','completed','cancelled')),
  channel text check (channel in ('whatsapp','email','phone','other')),
  message text,
  outcome text,
  completed_at timestamptz,
  created_at timestamptz not null default now()
);
create index on public.follow_ups(owner_id, status, scheduled_for);
create unique index follow_ups_one_open_per_quote on public.follow_ups(quote_id) where status = 'scheduled';
grant select, insert, update, delete on public.follow_ups to authenticated;
grant all on public.follow_ups to service_role;
alter table public.follow_ups enable row level security;
create policy "own followups" on public.follow_ups for all to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create table public.quote_events (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null,
  quote_id uuid not null references public.quotes(id) on delete cascade,
  type text not null,
  actor text not null default 'owner' check (actor in ('owner','customer','system')),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index on public.quote_events(quote_id, created_at);
grant select, insert on public.quote_events to authenticated;
grant all on public.quote_events to service_role;
alter table public.quote_events enable row level security;
create policy "own events select" on public.quote_events for select to authenticated using (owner_id = auth.uid());
create policy "own events insert" on public.quote_events for insert to authenticated with check (owner_id = auth.uid() and actor = 'owner');

-- Numbering + plan limit on insert
create or replace function public.quotes_before_insert() returns trigger language plpgsql security definer set search_path = public as $$
declare seq int; biz public.businesses; month_count int;
begin
  select * into biz from public.businesses where owner_id = new.owner_id for update;
  if not found then raise exception 'Complete your business profile first'; end if;
  if biz.plan = 'free' then
    select count(*) into month_count from public.quotes
      where owner_id = new.owner_id
        and created_at >= date_trunc('month', now() at time zone biz.timezone) at time zone biz.timezone;
    if month_count >= 3 then
      raise exception 'PLAN_LIMIT: The Free plan allows 3 new quotations per month.';
    end if;
  end if;
  update public.businesses set quote_seq = quote_seq + 1 where id = biz.id returning quote_seq into seq;
  new.number := 'QN-' || to_char(now() at time zone biz.timezone, 'YYYY') || '-' || lpad(seq::text, 4, '0');
  new.status := 'draft';
  new.share_token := null;
  new.finalized_at := null; new.responded_at := null; new.response_message := null;
  return new;
end $$;
create trigger quotes_before_insert before insert on public.quotes for each row execute function public.quotes_before_insert();

-- Status transition + immutability guard
create or replace function public.quotes_before_update() returns trigger language plpgsql set search_path = public as $$
begin
  new.updated_at := now();
  new.number := old.number; new.owner_id := old.owner_id;
  if current_user = 'authenticated' then
    -- owners cannot set customer response fields
    if new.responded_at is distinct from old.responded_at or new.response_message is distinct from old.response_message then
      raise exception 'Customer responses can only be recorded by the customer';
    end if;
  end if;
  if old.status <> 'draft' then
    -- content frozen once finalized
    if (new.customer_id, new.title, new.intro, new.issue_date, new.valid_until, new.currency, new.discount_type, new.discount_value,
        new.tax_enabled, new.tax_rate_bp, new.fees_cents, new.subtotal_cents, new.discount_cents, new.tax_cents, new.total_cents,
        new.payment_terms, new.deposit_info, new.payment_method, new.terms, new.customer_notes, new.share_token)
       is distinct from
       (old.customer_id, old.title, old.intro, old.issue_date, old.valid_until, old.currency, old.discount_type, old.discount_value,
        old.tax_enabled, old.tax_rate_bp, old.fees_cents, old.subtotal_cents, old.discount_cents, old.tax_cents, old.total_cents,
        old.payment_terms, old.deposit_info, old.payment_method, old.terms, old.customer_notes, old.share_token) then
      raise exception 'A finalized quotation cannot be edited. Duplicate it to make a revised version.';
    end if;
  end if;
  if new.status is distinct from old.status then
    if not (
      (old.status = 'draft' and new.status in ('pending','cancelled')) or
      (old.status = 'pending' and new.status in ('accepted','rejected','cancelled','expired')) or
      (old.status = 'accepted' and new.status = 'cancelled')
    ) then
      raise exception 'Invalid status change from % to %', old.status, new.status;
    end if;
    if current_user = 'authenticated' and new.status in ('accepted','rejected') then
      raise exception 'Only the customer can accept or decline a quotation';
    end if;
    if old.status = 'draft' and new.status = 'pending' then
      if new.share_token is null then
        new.share_token := encode(extensions.gen_random_bytes(18), 'hex');
      end if;
      new.finalized_at := now();
      new.link_enabled := true;
    end if;
    if new.status = 'cancelled' then new.link_enabled := false; end if;
  end if;
  return new;
end $$;
create trigger quotes_before_update before update on public.quotes for each row execute function public.quotes_before_update();

-- allow token set while draft->pending: token set by trigger after content check? content check only applies when old.status<>'draft', fine.

create or replace function public.quote_items_guard() returns trigger language plpgsql security definer set search_path = public as $$
declare st public.quote_status;
begin
  select status into st from public.quotes where id = coalesce(new.quote_id, old.quote_id);
  if st is not null and st <> 'draft' then
    raise exception 'Line items of a finalized quotation cannot be changed';
  end if;
  return coalesce(new, old);
end $$;
create trigger quote_items_guard before insert or update or delete on public.quote_items for each row execute function public.quote_items_guard();

-- Event log for status changes
create or replace function public.quotes_after_change() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    insert into public.quote_events(owner_id, quote_id, type, actor) values (new.owner_id, new.id, 'created', 'owner');
  elsif new.status is distinct from old.status then
    insert into public.quote_events(owner_id, quote_id, type, actor, metadata)
    values (new.owner_id, new.id,
      case new.status when 'pending' then 'finalized' else new.status::text end,
      case when new.status in ('accepted','rejected') then 'customer' when new.status = 'expired' then 'system' else 'owner' end,
      jsonb_build_object('from', old.status, 'to', new.status));
  elsif new.link_enabled is distinct from old.link_enabled then
    insert into public.quote_events(owner_id, quote_id, type, actor) values (new.owner_id, new.id, case when new.link_enabled then 'link_enabled' else 'link_disabled' end, 'owner');
  end if;
  return new;
end $$;
create trigger quotes_after_change after insert or update on public.quotes for each row execute function public.quotes_after_change();

-- Expire pending quotes past validity (called lazily)
create or replace function public.expire_my_quotes() returns integer language plpgsql security definer set search_path = public as $$
declare n int;
begin
  update public.quotes q set status = 'expired'
  from public.businesses b
  where b.owner_id = q.owner_id and q.owner_id = auth.uid() and q.status = 'pending'
    and q.valid_until < (now() at time zone b.timezone)::date;
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function public.expire_my_quotes() from public, anon;
grant execute on function public.expire_my_quotes() to authenticated;

-- Public read of a single quote by token
create or replace function public.get_public_quote(_token text) returns jsonb language plpgsql security definer set search_path = public as $$
declare q public.quotes; b public.businesses; c public.customers; today date;
begin
  if _token is null or char_length(_token) < 20 or char_length(_token) > 64 then return null; end if;
  select * into q from public.quotes where share_token = _token;
  if not found or q.status = 'draft' then return null; end if;
  select * into b from public.businesses where owner_id = q.owner_id;
  today := (now() at time zone b.timezone)::date;
  if q.status = 'pending' and q.valid_until < today then
    update public.quotes set status = 'expired' where id = q.id returning * into q;
  end if;
  if not q.link_enabled and q.status <> 'cancelled' then
    return jsonb_build_object('unavailable', true, 'business_name', b.name);
  end if;
  select * into c from public.customers where id = q.customer_id;
  return jsonb_build_object(
    'number', q.number, 'title', q.title, 'intro', q.intro, 'status', q.status,
    'issue_date', q.issue_date, 'valid_until', q.valid_until, 'currency', q.currency,
    'discount_type', q.discount_type, 'discount_value', q.discount_value,
    'tax_enabled', q.tax_enabled, 'tax_rate_bp', q.tax_rate_bp, 'tax_label', q.tax_label,
    'fees_cents', q.fees_cents, 'fees_label', q.fees_label,
    'subtotal_cents', q.subtotal_cents, 'discount_cents', q.discount_cents, 'tax_cents', q.tax_cents, 'total_cents', q.total_cents,
    'payment_terms', q.payment_terms, 'deposit_info', q.deposit_info, 'payment_method', q.payment_method,
    'terms', q.terms, 'customer_notes', q.customer_notes, 'responded_at', q.responded_at,
    'customer', jsonb_build_object('name', c.name, 'company', c.company),
    'business', jsonb_build_object('name', b.name, 'email', b.email, 'phone', b.phone, 'address', b.address,
       'website', b.website, 'logo_url', b.logo_url, 'vat_number', b.vat_number, 'registration_number', b.registration_number, 'locale', b.locale),
    'items', coalesce((select jsonb_agg(jsonb_build_object('description', i.description, 'quantity', i.quantity,
        'unit_price_cents', i.unit_price_cents, 'line_total_cents', i.line_total_cents) order by i.position)
        from public.quote_items i where i.quote_id = q.id), '[]'::jsonb)
  );
end $$;
revoke all on function public.get_public_quote(text) from public;
grant execute on function public.get_public_quote(text) to anon, authenticated;

-- Customer decision
create or replace function public.respond_to_quote(_token text, _decision text, _message text) returns jsonb language plpgsql security definer set search_path = public as $$
declare q public.quotes; b public.businesses; recent int;
begin
  if _decision not in ('accepted','rejected') then raise exception 'Invalid decision'; end if;
  if _message is not null and char_length(_message) > 1000 then raise exception 'Message is too long'; end if;
  select * into q from public.quotes where share_token = _token for update;
  if not found or q.status = 'draft' or not q.link_enabled then
    return jsonb_build_object('ok', false, 'reason', 'unavailable');
  end if;
  select * into b from public.businesses where owner_id = q.owner_id;
  if q.status = 'pending' and q.valid_until < (now() at time zone b.timezone)::date then
    update public.quotes set status = 'expired' where id = q.id;
    return jsonb_build_object('ok', false, 'reason', 'expired');
  end if;
  if q.status <> 'pending' then
    return jsonb_build_object('ok', false, 'reason', 'already_' || q.status::text, 'status', q.status);
  end if;
  select count(*) into recent from public.quote_events where quote_id = q.id and actor = 'customer' and created_at > now() - interval '1 minute';
  if recent > 5 then raise exception 'Too many attempts, please wait a moment'; end if;
  update public.quotes set status = _decision::public.quote_status, responded_at = now(),
    response_message = nullif(trim(_message), '') where id = q.id;
  update public.follow_ups set status = 'cancelled' where quote_id = q.id and status = 'scheduled';
  return jsonb_build_object('ok', true, 'status', _decision);
end $$;
revoke all on function public.respond_to_quote(text, text, text) from public;
grant execute on function public.respond_to_quote(text, text, text) to anon, authenticated;
