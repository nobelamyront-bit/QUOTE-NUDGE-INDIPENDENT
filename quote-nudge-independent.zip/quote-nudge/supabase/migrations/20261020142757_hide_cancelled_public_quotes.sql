-- QuoteNudge schema, part 2 of 2: stops cancelled quotes from being shown on the public share link.
-- Moved unchanged from drizzle/migrations/0001_hide_cancelled_public_quotes.sql (only this comment header was added).
-- Replaces get_public_quote() from part 1, so run it AFTER part 1.
create or replace function public.get_public_quote(_token text) returns jsonb language plpgsql security definer set search_path = public as $$
declare q public.quotes; b public.businesses; c public.customers; today date;
begin
  if _token is null or char_length(_token) < 20 or char_length(_token) > 64 then return null; end if;
  select * into q from public.quotes where share_token = _token;
  if not found or q.status = 'draft' then return null; end if;
  select * into b from public.businesses where owner_id = q.owner_id;
  if not q.link_enabled or q.status = 'cancelled' then
    return jsonb_build_object('unavailable', true, 'business_name', b.name);
  end if;
  today := (now() at time zone b.timezone)::date;
  if q.status = 'pending' and q.valid_until < today then
    update public.quotes set status = 'expired' where id = q.id returning * into q;
  end if;
  select * into c from public.customers where id = q.customer_id;
  return jsonb_build_object(
    'number', q.number, 'title', q.title, 'intro', q.intro, 'status', q.status,
    'issue_date', q.issue_date, 'valid_until', q.valid_until, 'currency', q.currency,
    'discount_type', q.discount_type, 'discount_value', q.discount_value,
    'tax_enabled', q.tax_enabled, 'tax_rate_bp', q.tax_rate_bp, 'tax_label', q.tax_label,
    'fees_cents', q.fees_cents, 'fees_label', q.fees_label,
    'subtotal_cents', q.subtotal_cents, 'discount_cents', q.discount_cents, 'tax_cents', q.tax_cents, 'total_cents', q.total_cents,
    'payment_terms', q.payment_terms, 'deposit_info', q.deposit_info, 'payment_method', q.payment_method,
    'terms', q.terms, 'customer_notes', q.customer_notes, 'responded_at', q.responded_at,
    'customer', jsonb_build_object('name', c.name, 'company', c.company),
    'business', jsonb_build_object('name', b.name, 'email', b.email, 'phone', b.phone, 'address', b.address,
       'website', b.website, 'logo_url', b.logo_url, 'vat_number', b.vat_number, 'registration_number', b.registration_number, 'locale', b.locale),
    'items', coalesce((select jsonb_agg(jsonb_build_object('description', i.description, 'quantity', i.quantity,
        'unit_price_cents', i.unit_price_cents, 'line_total_cents', i.line_total_cents) order by i.position)
        from public.quote_items i where i.quote_id = q.id), '[]'::jsonb)
  );
end $$;
revoke all on function public.get_public_quote(text) from public;
grant execute on function public.get_public_quote(text) to anon, authenticated;