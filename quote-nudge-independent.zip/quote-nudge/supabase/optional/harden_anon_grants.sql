-- =====================================================================================
-- OPTIONAL hardening (defense in depth). NOT part of the original schema, so it is kept
-- outside supabase/migrations/ and will not be applied automatically by `supabase db push`.
--
-- Why: new Supabase projects usually grant the logged-out "anon" role table privileges by default.
-- Row Level Security already blocks every row for anon (no anon policies exist), so this is safe
-- today, but removing the privileges means a future mistake (e.g. a new permissive policy) can't
-- accidentally expose data to the public.
--
-- Safe for this app: logged-out visitors only use Supabase Auth and the two SECURITY DEFINER RPCs
-- (get_public_quote / respond_to_quote), which run with the function owner's rights, not anon's.
-- Run once in the SQL Editor after the migrations.
-- =====================================================================================

-- Remove existing table privileges from anon in the public schema.
revoke all on all tables in schema public from anon;

-- Make future tables created in the public schema skip the automatic anon grant as well.
alter default privileges in schema public revoke all on tables from anon;

-- To undo (rarely needed):  grant select, insert, update, delete on all tables in schema public to anon;
