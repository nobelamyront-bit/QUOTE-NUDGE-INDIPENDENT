import { useState } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { useServerFn } from '@tanstack/react-start';
import { Copy, MessageCircle, CopyPlus, Ban, Pencil } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useWorkspace, useAction } from '@/lib/workspace';
import { duplicateQuote } from '@/lib/quotes.functions';
import { formatMoney } from '@/lib/money';
import { formatDate, formatDateTime, toWhatsAppNumber } from '@/lib/format';
import { shareMessage, whatsappUrl } from '@/lib/messages';
import { shareLink } from '@/hooks/use-business';
import { StatusBadge } from '@/components/app/StatusBadge';
import { Heading, Missing } from './shared';
import { QuoteEditor } from './QuoteEditor';

export function QuoteDetail({ id }: { id: string }) {
  const ws = useWorkspace();
  const navigate = useNavigate();
  const dup = useServerFn(duplicateQuote);
  const [editing, setEditing] = useState(false);
  const q = ws.quotes.find(x => x.id === id);
  const duplicate = useAction(async () => { const r = await dup({ data: { id } }); await navigate({ to: '/quotes/$id', params: { id: r.id } }); }, 'Copy created as a new draft');
  const cancel = useAction(async () => { const { error } = await supabase.from('quotes').update({ status: 'cancelled' }).eq('id', id); if (error) throw new Error(error.message); }, 'Quotation cancelled');
  if (!q) return <Missing/>;
  if (q.status === 'draft' && editing) return <QuoteEditor quote={q}/>;
  const customer = ws.customers.find(c => c.id === q.customer_id);
  const items = ws.items.filter(i => i.quote_id === q.id).sort((a, b) => a.position - b.position);
  const events = ws.events.filter(e => e.quote_id === q.id);
  const money = (c: number) => formatMoney(c, q.currency);
  const link = shareLink(q.share_token);
  const msg = shareMessage({ customerName: customer?.name ?? 'there', quoteNumber: q.number, title: q.title, issueDate: q.issue_date, validUntil: q.valid_until, total: money(q.total_cents), link, businessName: ws.business?.name ?? '', ownerName: ws.business?.owner_name ?? undefined });
  const copy = async (text: string, label: string) => { await navigator.clipboard.writeText(text); toast.success(`${label} copied`); };
  return <div className="max-w-4xl">
    <Heading eyebrow={q.number} title={q.title} description={`${customer?.name ?? 'Customer'} · valid until ${formatDate(q.valid_until)}`} action={<StatusBadge status={q.status}/>}/>
    <div className="mb-8 flex flex-wrap gap-2">
      {q.status === 'draft' && <Button onClick={() => setEditing(true)}><Pencil/>Edit draft</Button>}
      {link && q.status === 'pending' && <><Button onClick={() => copy(link, 'Link')}><Copy/>Copy link</Button><Button variant="outline" onClick={() => copy(msg, 'Message')}><Copy/>Copy message</Button><Button variant="outline" asChild><a href={whatsappUrl(msg, toWhatsAppNumber(customer?.phone))} target="_blank" rel="noreferrer"><MessageCircle/>Open WhatsApp</a></Button></>}
      <Button variant="ghost" onClick={() => duplicate.mutate(undefined)} disabled={duplicate.isPending}><CopyPlus/>Duplicate</Button>
      {(q.status === 'pending' || q.status === 'accepted') && <Button variant="ghost" onClick={() => { if (confirm('Cancel this quotation? The customer link will show it as cancelled.')) cancel.mutate(undefined); }}><Ban/>Cancel</Button>}
    </div>
    {link && q.status === 'pending' && <p className="mb-6 text-xs text-muted-foreground">Opening WhatsApp prepares the message — you still need to press send yourself.</p>}
    {q.response_message && <div className="mb-6 rounded-lg border bg-card p-4 text-sm"><p className="mb-1 font-semibold">Customer said ({formatDateTime(q.responded_at)})</p><p>{q.response_message}</p></div>}
    <table className="mb-6 w-full text-sm"><thead><tr className="border-b text-left text-xs uppercase text-muted-foreground"><th className="py-2">Item</th><th>Qty</th><th className="text-right">Price</th><th className="text-right">Total</th></tr></thead><tbody>{items.map(i => <tr key={i.id} className="border-b"><td className="py-3">{i.description}</td><td>{i.quantity}</td><td className="text-right tabular">{money(i.unit_price_cents)}</td><td className="text-right tabular">{money(i.line_total_cents)}</td></tr>)}</tbody></table>
    <dl className="ml-auto mb-10 max-w-xs space-y-1 text-sm"><div className="flex justify-between"><dt>Subtotal</dt><dd>{money(q.subtotal_cents)}</dd></div>{q.discount_cents > 0 && <div className="flex justify-between"><dt>Discount</dt><dd>−{money(q.discount_cents)}</dd></div>}{q.tax_enabled && <div className="flex justify-between"><dt>{q.tax_label}</dt><dd>{money(q.tax_cents)}</dd></div>}{q.fees_cents > 0 && <div className="flex justify-between"><dt>{q.fees_label || 'Fees'}</dt><dd>{money(q.fees_cents)}</dd></div>}<div className="flex justify-between border-t pt-2 text-base font-semibold"><dt>Total</dt><dd>{money(q.total_cents)}</dd></div></dl>
    {q.internal_notes && <p className="mb-6 text-sm"><span className="font-semibold">Internal notes:</span> {q.internal_notes}</p>}
    <h2 className="mb-3 font-semibold">Activity</h2><ul className="space-y-2 text-sm">{events.map(e => <li key={e.id} className="flex justify-between border-b pb-2"><span className="capitalize">{e.type.replace(/_/g, ' ')}</span><span className="text-muted-foreground">{formatDateTime(e.created_at)}</span></li>)}</ul>
  </div>;
}
