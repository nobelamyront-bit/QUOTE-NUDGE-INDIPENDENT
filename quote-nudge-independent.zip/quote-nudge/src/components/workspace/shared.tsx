import { useRouter, Link, type ErrorComponentProps } from '@tanstack/react-router';
import { Button } from '@/components/ui/button';
import type { ReactNode } from 'react';
import { FileText, ArrowUpRight } from 'lucide-react';
export function PageError({ error, reset }: ErrorComponentProps) { const router = useRouter(); return <div className="p-10"><h1 className="text-2xl font-semibold">This page couldn’t load</h1><p className="my-4 text-muted-foreground">{error instanceof Error ? error.message : 'Please try again.'}</p><Button onClick={async () => { await router.invalidate(); reset(); }}>Try again</Button></div>; }
export function Missing() { return <div className="p-12">Quotation not found.</div>; }
export function Heading({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description?: string; action?: ReactNode }) { return <div className="mb-8 flex flex-wrap items-end justify-between gap-4"><div>{eyebrow && <p className="mb-2 text-xs font-semibold uppercase text-muted-foreground">{eyebrow}</p>}<h1 className="font-display text-3xl font-semibold">{title}</h1>{description && <p className="mt-2 text-sm text-muted-foreground">{description}</p>}</div>{action}</div>; }
export function Empty({ title, children, action }: { title: string; children?: ReactNode; action?: ReactNode }) { return <div className="flex flex-col items-center border-y py-16 text-center"><FileText className="mb-4 size-9 text-muted-foreground"/><h2 className="text-xl font-semibold">{title}</h2><p className="mb-6 mt-2 max-w-md text-sm text-muted-foreground">{children}</p>{action}</div>; }
export function CreateButton() { return <Button asChild><Link to="/quotes/new"><span className="text-lg">+</span>Create quotation</Link></Button>; }
export function SectionLink({ to, children }: { to: '/quotes' | '/follow-ups'; children: ReactNode }) { return <Button asChild variant="ghost" size="sm"><Link to={to}>{children}<ArrowUpRight/></Link></Button>; }
