import { useWorkspace } from '@/lib/workspace';
import { formatMoney } from '@/lib/money';
import { ALL_STATUSES, STATUS_LABEL } from '@/lib/status';
import { Heading } from './shared';

export function Reports() {
  const { quotes, business } = useWorkspace();
  const cur = business?.currency ?? 'ZAR';
  const sent = quotes.filter(q => q.status !== 'draft');
  const won = quotes.filter(q => q.status === 'accepted');
  const decided = quotes.filter(q => q.status === 'accepted' || q.status === 'rejected');
  const rate = decided.length ? Math.round((won.length / decided.length) * 100) : 0;
  const sum = (s: string) => quotes.filter(q => q.status === s).reduce((a, q) => a + q.total_cents, 0);
  const stats = [
    ['Quotations shared', String(sent.length)],
    ['Won value', formatMoney(sum('accepted'), cur)],
    ['Awaiting decision', formatMoney(sum('pending'), cur)],
    ['Win rate (decided)', `${rate}%`],
  ];
  return <><Heading eyebrow="How you're doing" title="Reports" description="Simple numbers from your own quotations."/>
    <div className="mb-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{stats.map(([l, v]) => <div key={l} className="rounded-lg border bg-card p-5"><p className="text-xs uppercase text-muted-foreground">{l}</p><p className="mt-2 text-2xl font-semibold tabular">{v}</p></div>)}</div>
    <table className="w-full max-w-xl text-sm"><thead><tr className="border-b text-left text-xs uppercase text-muted-foreground"><th className="py-2">Status</th><th>Count</th><th className="text-right">Value</th></tr></thead><tbody>{ALL_STATUSES.map(s => <tr key={s} className="border-b"><td className="py-3">{STATUS_LABEL[s]}</td><td>{quotes.filter(q => q.status === s).length}</td><td className="text-right tabular">{formatMoney(sum(s), cur)}</td></tr>)}</tbody></table></>;
}
