import { useState } from 'react';
import { Link } from '@tanstack/react-router';
import { Copy, MessageCircle, Check } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useWorkspace, useAction } from '@/lib/workspace';
import { buildMessage, whatsappUrl, type Tone } from '@/lib/messages';
import { formatMoney } from '@/lib/money';
import { addBusinessDays, formatDate, toWhatsAppNumber } from '@/lib/format';
import { shareLink } from '@/hooks/use-business';
import { Heading, Empty } from './shared';
import type { FollowUp } from '@/hooks/use-business';

export function FollowUps() {
  const ws = useWorkspace();
  const open = ws.followups.filter(f => f.status === 'scheduled' && ws.quotes.find(q => q.id === f.quote_id)?.status === 'pending');
  return <><Heading eyebrow="Stay top of mind" title="Follow-ups" description="Reminders are prepared for you. You send them yourself on WhatsApp or by copying the message."/>
    {open.length ? <div className="space-y-4">{open.map(f => <Card key={f.id} f={f}/>)}</div> : <Empty title="Nothing to follow up">When you share a quotation, a follow-up reminder is scheduled automatically.</Empty>}</>;
}

function Card({ f }: { f: FollowUp }) {
  const ws = useWorkspace();
  const [tone, setTone] = useState<Tone>('friendly');
  const q = ws.quotes.find(x => x.id === f.quote_id)!;
  const c = ws.customers.find(x => x.id === f.customer_id);
  const msg = buildMessage(tone, { customerName: c?.name ?? 'there', quoteNumber: q.number, title: q.title, issueDate: q.issue_date, validUntil: q.valid_until, total: formatMoney(q.total_cents, q.currency), link: shareLink(q.share_token), businessName: ws.business?.name ?? '', ownerName: ws.business?.owner_name ?? undefined });
  const due = f.scheduled_for && new Date(f.scheduled_for) <= new Date();
  const done = useAction(async () => {
    const { error } = await supabase.from('follow_ups').update({ status: 'completed', completed_at: new Date().toISOString(), channel: 'whatsapp', message: msg }).eq('id', f.id);
    if (error) throw new Error(error.message);
    const next = addBusinessDays(new Date(), ws.business?.followup_delay_days ?? 2); next.setHours(9, 0, 0, 0);
    if (next.toISOString().slice(0, 10) <= q.valid_until) await supabase.from('follow_ups').insert({ owner_id: ws.userId, quote_id: q.id, customer_id: q.customer_id, scheduled_for: next.toISOString(), status: 'scheduled' });
  }, 'Marked as followed up');
  return <div className="rounded-lg border bg-card p-5">
    <div className="mb-3 flex flex-wrap justify-between gap-2"><div><Link to="/quotes/$id" params={{ id: q.id }} className="font-semibold hover:text-primary">{q.title}</Link><p className="text-xs text-muted-foreground">{q.number} · {c?.name}</p></div><span className={due ? 'text-sm font-semibold text-primary' : 'text-sm text-muted-foreground'}>{due ? 'Due now' : `Due ${formatDate(f.scheduled_for)}`}</span></div>
    <div className="mb-3 flex gap-1">{(['friendly', 'professional', 'final'] as Tone[]).map(t => <Button key={t} size="sm" variant={tone === t ? 'secondary' : 'ghost'} onClick={() => setTone(t)} className="capitalize">{t}</Button>)}</div>
    <pre className="mb-4 whitespace-pre-wrap rounded-md bg-muted p-3 font-sans text-sm">{msg}</pre>
    <div className="flex flex-wrap gap-2"><Button variant="outline" size="sm" onClick={async () => { await navigator.clipboard.writeText(msg); toast.success('Message copied'); }}><Copy/>Copy</Button><Button variant="outline" size="sm" asChild><a href={whatsappUrl(msg, toWhatsAppNumber(c?.phone))} target="_blank" rel="noreferrer"><MessageCircle/>Open WhatsApp</a></Button><Button size="sm" onClick={() => done.mutate(undefined)} disabled={done.isPending}><Check/>I sent it</Button></div>
  </div>;
}
