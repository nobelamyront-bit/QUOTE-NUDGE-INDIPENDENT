import { useMemo, useState } from 'react';
import { Link, useNavigate } from '@tanstack/react-router';
import { useServerFn } from '@tanstack/react-start';
import { Plus, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useWorkspace, useAction } from '@/lib/workspace';
import { saveQuote, type SaveQuoteInput } from '@/lib/quotes.functions';
import { calculateTotals, centsToInput, formatMoney, parseMoneyToCents, type DiscountType } from '@/lib/money';
import { addDays, todayInTz } from '@/lib/format';
import type { Quote } from '@/hooks/use-business';
import { Heading } from './shared';

type Row = { description: string; quantity: string; price: string };
const sel = 'h-9 w-full rounded-md border bg-background px-3 text-sm';

export function QuoteEditor({ quote }: { quote?: Quote }) {
  const ws = useWorkspace();
  const b = ws.business;
  const navigate = useNavigate();
  const save = useServerFn(saveQuote);
  const today = todayInTz(b?.timezone ?? 'Africa/Johannesburg');
  const existing = quote ? ws.items.filter(i => i.quote_id === quote.id).sort((a, c) => a.position - c.position) : [];
  const [f, setF] = useState({
    customer_id: quote?.customer_id ?? '', title: quote?.title ?? '', intro: quote?.intro ?? '',
    issue_date: quote?.issue_date ?? today, valid_until: quote?.valid_until ?? addDays(today, b?.validity_days ?? 14),
    discount_type: (quote?.discount_type ?? 'none') as DiscountType,
    discount: quote ? (quote.discount_type === 'percent' ? String(quote.discount_value / 100) : centsToInput(quote.discount_value)) : '0',
    tax_enabled: quote?.tax_enabled ?? b?.tax_enabled ?? false, tax_rate: String((quote?.tax_rate_bp ?? b?.tax_rate_bp ?? 1500) / 100),
    tax_label: quote?.tax_label ?? b?.tax_label ?? 'VAT', fees: centsToInput(quote?.fees_cents ?? 0), fees_label: quote?.fees_label ?? '',
    payment_terms: quote?.payment_terms ?? b?.default_payment_terms ?? '', terms: quote?.terms ?? b?.default_terms ?? '',
    customer_notes: quote?.customer_notes ?? '', internal_notes: quote?.internal_notes ?? '',
  });
  const [rows, setRows] = useState<Row[]>(existing.length ? existing.map(i => ({ description: i.description, quantity: String(i.quantity), price: centsToInput(i.unit_price_cents) })) : [{ description: '', quantity: '1', price: '' }]);
  const set = (k: keyof typeof f, v: string | boolean) => setF(p => ({ ...p, [k]: v }));
  const currency = quote?.currency ?? b?.currency ?? 'ZAR';
  const input = useMemo(() => {
    const items = rows.map(r => ({ description: r.description, quantity: Number(r.quantity) || 0, unit_price_cents: parseMoneyToCents(r.price) ?? 0 }));
    const discount_value = f.discount_type === 'percent' ? Math.round((Number(f.discount) || 0) * 100) : (parseMoneyToCents(f.discount) ?? 0);
    return { items, discount_type: f.discount_type, discount_value, tax_enabled: f.tax_enabled, tax_rate_bp: Math.round((Number(f.tax_rate) || 0) * 100), fees_cents: parseMoneyToCents(f.fees) ?? 0 };
  }, [rows, f]);
  const totals = calculateTotals(input);
  const submit = useAction(async (finalize: boolean) => {
    const payload: SaveQuoteInput = { id: quote?.id, customer_id: f.customer_id, title: f.title, intro: f.intro, issue_date: f.issue_date, valid_until: f.valid_until, currency, ...input, tax_label: f.tax_label || 'VAT', fees_label: f.fees_label, payment_terms: f.payment_terms, deposit_info: null, payment_method: null, terms: f.terms, customer_notes: f.customer_notes, internal_notes: f.internal_notes, finalize };
    const res = await save({ data: payload });
    await navigate({ to: '/quotes/$id', params: { id: res.id } });
  }, 'Quotation saved');

  if (!ws.customers.length) return <><Heading title="New quotation"/><p className="text-muted-foreground">Add a customer first. <Link to="/customers" search={{ search: "" }} className="font-semibold text-primary">Add customer</Link></p></>;
  const money = (c: number) => formatMoney(c, currency);
  return <form onSubmit={e => { e.preventDefault(); submit.mutate(false); }} className="max-w-4xl space-y-8">
    <Heading eyebrow={quote?.number ?? 'Draft'} title={quote ? 'Edit quotation' : 'New quotation'} description="Drafts can be changed freely. Once shared, the quotation is locked."/>
    <section className="grid gap-4 md:grid-cols-2">
      <div><Label>Customer</Label><select className={sel} value={f.customer_id} onChange={e => set('customer_id', e.target.value)} required><option value="">Choose a customer</option>{ws.customers.map(c => <option key={c.id} value={c.id}>{c.name}{c.company ? ` — ${c.company}` : ''}</option>)}</select></div>
      <div><Label>Title</Label><Input value={f.title} onChange={e => set('title', e.target.value)} placeholder="Kitchen renovation" required/></div>
      <div><Label>Issue date</Label><Input type="date" value={f.issue_date} onChange={e => set('issue_date', e.target.value)}/></div>
      <div><Label>Valid until</Label><Input type="date" value={f.valid_until} onChange={e => set('valid_until', e.target.value)}/></div>
      <div className="md:col-span-2"><Label>Introduction</Label><Textarea value={f.intro} onChange={e => set('intro', e.target.value)} placeholder="Thank you for the opportunity…"/></div>
    </section>
    <section><h2 className="mb-3 font-semibold">Line items</h2><div className="space-y-2">{rows.map((r, i) => <div key={i} className="grid grid-cols-[1fr_80px_120px_110px_36px] items-center gap-2">
      <Input aria-label="Description" value={r.description} placeholder="Description" onChange={e => setRows(rs => rs.map((x, j) => j === i ? { ...x, description: e.target.value } : x))}/>
      <Input aria-label="Quantity" inputMode="decimal" value={r.quantity} onChange={e => setRows(rs => rs.map((x, j) => j === i ? { ...x, quantity: e.target.value } : x))}/>
      <Input aria-label="Unit price" inputMode="decimal" value={r.price} placeholder="0.00" onChange={e => setRows(rs => rs.map((x, j) => j === i ? { ...x, price: e.target.value } : x))}/>
      <span className="text-right text-sm tabular">{money(totals.line_totals[i] ?? 0)}</span>
      <Button type="button" variant="ghost" size="icon" aria-label="Remove item" disabled={rows.length === 1} onClick={() => setRows(rs => rs.filter((_, j) => j !== i))}><Trash2/></Button></div>)}</div>
      <Button type="button" variant="outline" size="sm" className="mt-3" onClick={() => setRows(rs => [...rs, { description: '', quantity: '1', price: '' }])}><Plus/>Add item</Button></section>
    <section className="grid gap-6 md:grid-cols-2">
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-2"><div><Label>Discount</Label><select className={sel} value={f.discount_type} onChange={e => set('discount_type', e.target.value)}><option value="none">None</option><option value="percent">Percent</option><option value="fixed">Fixed amount</option></select></div>{f.discount_type !== 'none' && <div><Label>{f.discount_type === 'percent' ? '%' : 'Amount'}</Label><Input value={f.discount} onChange={e => set('discount', e.target.value)}/></div>}</div>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.tax_enabled} onChange={e => set('tax_enabled', e.target.checked)}/>Charge tax</label>
        {f.tax_enabled && <div className="grid grid-cols-2 gap-2"><div><Label>Tax label</Label><Input value={f.tax_label} onChange={e => set('tax_label', e.target.value)}/></div><div><Label>Rate %</Label><Input value={f.tax_rate} onChange={e => set('tax_rate', e.target.value)}/></div></div>}
        <div className="grid grid-cols-2 gap-2"><div><Label>Extra fee</Label><Input value={f.fees} onChange={e => set('fees', e.target.value)}/></div><div><Label>Fee label</Label><Input value={f.fees_label} placeholder="Call-out fee" onChange={e => set('fees_label', e.target.value)}/></div></div>
      </div>
      <dl className="space-y-2 rounded-lg border bg-card p-5 text-sm">
        <div className="flex justify-between"><dt>Subtotal</dt><dd className="tabular">{money(totals.subtotal_cents)}</dd></div>
        {totals.discount_cents > 0 && <div className="flex justify-between"><dt>Discount</dt><dd className="tabular">−{money(totals.discount_cents)}</dd></div>}
        {f.tax_enabled && <div className="flex justify-between"><dt>{f.tax_label}</dt><dd className="tabular">{money(totals.tax_cents)}</dd></div>}
        {totals.fees_cents > 0 && <div className="flex justify-between"><dt>{f.fees_label || 'Fees'}</dt><dd className="tabular">{money(totals.fees_cents)}</dd></div>}
        <div className="flex justify-between border-t pt-3 text-lg font-semibold"><dt>Total</dt><dd className="tabular">{money(totals.total_cents)}</dd></div>
      </dl>
    </section>
    <section className="grid gap-4 md:grid-cols-2">
      <div><Label>Payment terms</Label><Textarea value={f.payment_terms} onChange={e => set('payment_terms', e.target.value)}/></div>
      <div><Label>Terms &amp; conditions</Label><Textarea value={f.terms} onChange={e => set('terms', e.target.value)}/></div>
      <div><Label>Notes for customer</Label><Textarea value={f.customer_notes} onChange={e => set('customer_notes', e.target.value)}/></div>
      <div><Label>Internal notes (never shown to customer)</Label><Textarea value={f.internal_notes} onChange={e => set('internal_notes', e.target.value)}/></div>
    </section>
    <div className="flex flex-wrap gap-2 border-t pt-6"><Button type="submit" variant="outline" disabled={submit.isPending}>Save draft</Button><Button type="button" disabled={submit.isPending} onClick={() => submit.mutate(true)}>Finalise &amp; get share link</Button></div>
  </form>;
}
