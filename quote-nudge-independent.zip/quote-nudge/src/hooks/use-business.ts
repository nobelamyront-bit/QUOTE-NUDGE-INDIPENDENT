import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type Business = Database["public"]["Tables"]["businesses"]["Row"];
export type Customer = Database["public"]["Tables"]["customers"]["Row"];
export type Quote = Database["public"]["Tables"]["quotes"]["Row"];
export type QuoteItem = Database["public"]["Tables"]["quote_items"]["Row"];
export type FollowUp = Database["public"]["Tables"]["follow_ups"]["Row"];
export type QuoteEvent = Database["public"]["Tables"]["quote_events"]["Row"];

export const businessKey = ["business"] as const;

export function useBusiness() {
  return useQuery({
    queryKey: businessKey,
    queryFn: async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return null;
      const { data, error } = await supabase.from("businesses").select("*").eq("owner_id", u.user.id).maybeSingle();
      if (error) throw error;
      return data;
    },
    staleTime: 60_000,
  });
}

export type QuoteWithCustomer = Quote & { customers: Pick<Customer, "id" | "name" | "company" | "phone" | "email"> | null; follow_ups: Pick<FollowUp, "id" | "status" | "scheduled_for" | "completed_at">[] };

export function useQuotes() {
  return useQuery({
    queryKey: ["quotes"],
    queryFn: async () => {
      await supabase.rpc("expire_my_quotes");
      const { data, error } = await supabase
        .from("quotes")
        .select("*, customers(id, name, company, phone, email), follow_ups(id, status, scheduled_for, completed_at)")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as unknown as QuoteWithCustomer[];
    },
  });
}

export function lastFollowUp(q: QuoteWithCustomer): string | null {
  const done = q.follow_ups.filter((f) => f.completed_at).map((f) => f.completed_at!).sort();
  return done[done.length - 1] ?? null;
}

export function shareLink(token: string | null): string {
  if (!token) return "";
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  return `${origin}/q/${token}`;
}
