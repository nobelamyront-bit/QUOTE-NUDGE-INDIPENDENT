/**
 * Monetary calculations in integer minor units (cents).
 * Calculation order:
 *  1. line total = round(quantity * unit price)
 *  2. subtotal = sum of line totals
 *  3. discount (percent in basis points, or fixed cents), capped at subtotal
 *  4. tax = round((subtotal - discount) * rate)
 *  5. + additional fees
 *  6. total
 */
export type DiscountType = "none" | "percent" | "fixed";

export interface ItemInput {
  description: string;
  quantity: number;
  unit_price_cents: number;
}

export interface TotalsInput {
  items: ItemInput[];
  discount_type: DiscountType;
  /** percent → basis points (1000 = 10%); fixed → cents */
  discount_value: number;
  tax_enabled: boolean;
  /** basis points: 1500 = 15% */
  tax_rate_bp: number;
  fees_cents: number;
}

export interface Totals {
  line_totals: number[];
  subtotal_cents: number;
  discount_cents: number;
  tax_cents: number;
  fees_cents: number;
  total_cents: number;
}

export function lineTotal(quantity: number, unitPriceCents: number): number {
  // quantity has up to 3 decimals; work in thousandths to avoid float drift
  const qMilli = Math.round(quantity * 1000);
  return Math.round((qMilli * unitPriceCents) / 1000);
}

export function calculateTotals(input: TotalsInput): Totals {
  const line_totals = input.items.map((i) => lineTotal(i.quantity, i.unit_price_cents));
  const subtotal_cents = line_totals.reduce((a, b) => a + b, 0);
  let discount_cents = 0;
  if (input.discount_type === "percent") {
    const bp = Math.min(Math.max(input.discount_value, 0), 10000);
    discount_cents = Math.round((subtotal_cents * bp) / 10000);
  } else if (input.discount_type === "fixed") {
    discount_cents = Math.max(input.discount_value, 0);
  }
  discount_cents = Math.min(discount_cents, subtotal_cents);
  const taxable = subtotal_cents - discount_cents;
  const tax_cents = input.tax_enabled
    ? Math.round((taxable * Math.min(Math.max(input.tax_rate_bp, 0), 10000)) / 10000)
    : 0;
  const fees_cents = Math.max(input.fees_cents, 0);
  const total_cents = Math.max(taxable + tax_cents + fees_cents, 0);
  return { line_totals, subtotal_cents, discount_cents, tax_cents, fees_cents, total_cents };
}

/** Parse "1 234,50" / "1234.5" / "R 99" into cents. Returns null if invalid. */
export function parseMoneyToCents(value: string): number | null {
  const cleaned = value.replace(/[^\d.,-]/g, "").replace(/\s/g, "");
  if (!cleaned) return null;
  const normalized = cleaned.includes(",") && !cleaned.includes(".") ? cleaned.replace(",", ".") : cleaned.replace(/,/g, "");
  if (!/^-?\d+(\.\d{0,2})?$/.test(normalized)) return null;
  const [whole = "0", frac = ""] = normalized.split(".");
  const sign = whole.startsWith("-") ? -1 : 1;
  return sign * (Math.abs(parseInt(whole, 10)) * 100 + parseInt((frac + "00").slice(0, 2), 10));
}

export function centsToInput(cents: number): string {
  return (cents / 100).toFixed(2);
}

export function formatMoney(cents: number, currency = "ZAR", locale = "en-ZA"): string {
  try {
    return new Intl.NumberFormat(locale, { style: "currency", currency, minimumFractionDigits: 2 }).format(cents / 100);
  } catch {
    return `${currency} ${(cents / 100).toFixed(2)}`;
  }
}
