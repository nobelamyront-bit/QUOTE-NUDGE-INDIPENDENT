import { createServerFn } from '@tanstack/react-start';
import { createClient } from '@supabase/supabase-js';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import type { Database } from '@/integrations/supabase/types';

export const getWorkspace = createServerFn({ method: 'GET' }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const db = context.supabase;
  const expired = await db.rpc('expire_my_quotes');
  if (expired.error) throw new Error(expired.error.message);
  const [business, customers, quotes, items, followups, events] = await Promise.all([
    db.from('businesses').select('*').eq('owner_id', context.userId).maybeSingle(),
    db.from('customers').select('*').order('name'),
    db.from('quotes').select('*').order('created_at', { ascending: false }),
    db.from('quote_items').select('*').order('position'),
    db.from('follow_ups').select('*').order('scheduled_for'),
    db.from('quote_events').select('*').order('created_at', { ascending: false }),
  ]);
  for (const result of [business, customers, quotes, items, followups, events]) if (result.error) throw new Error(result.error.message);
  return { business: business.data, customers: customers.data ?? [], quotes: quotes.data ?? [], items: items.data ?? [], followups: followups.data ?? [], events: events.data ?? [], userId: context.userId };
});

function publicClient() {
  // CHANGED: falls back to the VITE_* values so only two Supabase variables are needed in Netlify.
  // ACTION REQUIRED (production): set VITE_SUPABASE_URL + VITE_SUPABASE_PUBLISHABLE_KEY in the Netlify
  // dashboard with scopes that include "Builds" and "Functions". This anonymous client is used by the
  // public quote page (/q/:token), which only calls the get_public_quote / respond_to_quote RPCs.
  const url = process.env['SUPABASE_URL'] || process.env['VITE_SUPABASE_URL'];
  const key = process.env['SUPABASE_PUBLISHABLE_KEY'] || process.env['VITE_SUPABASE_PUBLISHABLE_KEY'];
  if (!url || !key) throw new Error('Quotation service unavailable');
  return createClient<Database>(url, key, { auth: { persistSession: false, autoRefreshToken: false }, global: { fetch: (input, init) => {
    const headers = new Headers(init?.headers);
    if (headers.get('Authorization') === `Bearer ${key}`) headers.delete('Authorization');
    headers.set('apikey', key);
    return fetch(input, { ...init, headers });
  } } });
}
export const getPublicQuote = createServerFn({ method: 'GET' }).inputValidator((input: { token: string }) => z.object({ token: z.string().min(20).max(64) }).parse(input)).handler(async ({ data }) => {
  const result = await publicClient().rpc('get_public_quote', { _token: data.token });
  if (result.error) throw new Error('Unable to load this quotation. Please try again.');
  return result.data;
});
export const respondPublicQuote = createServerFn({ method: 'POST' }).inputValidator((input: { token: string; decision: 'accepted' | 'rejected'; message: string }) => z.object({ token: z.string().min(20).max(64), decision: z.enum(['accepted', 'rejected']), message: z.string().max(1000) }).parse(input)).handler(async ({ data }) => {
  const result = await publicClient().rpc('respond_to_quote', { _token: data.token, _decision: data.decision, _message: data.message });
  if (result.error) throw new Error('Your response could not be saved. Please try again.');
  return result.data;
});
