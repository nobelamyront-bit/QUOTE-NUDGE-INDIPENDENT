import { describe, it, expect } from "vitest";
import { calculateTotals, lineTotal, parseMoneyToCents } from "./money";

const items = [
  { description: "Website design", quantity: 1, unit_price_cents: 350000 },
  { description: "Hosting setup", quantity: 1, unit_price_cents: 75000 },
  { description: "Support", quantity: 3, unit_price_cents: 25000 },
];

describe("quotation totals", () => {
  it("sums line items into the subtotal (R5,000.00 brief example)", () => {
    const t = calculateTotals({ items, discount_type: "none", discount_value: 0, tax_enabled: false, tax_rate_bp: 0, fees_cents: 0 });
    expect(t.subtotal_cents).toBe(500000);
    expect(t.total_cents).toBe(500000);
  });

  it("applies discount before tax, then adds fees", () => {
    const t = calculateTotals({ items, discount_type: "percent", discount_value: 1000, tax_enabled: true, tax_rate_bp: 1500, fees_cents: 10000 });
    expect(t.discount_cents).toBe(50000);
    expect(t.tax_cents).toBe(67500); // 15% of 4500.00
    expect(t.total_cents).toBe(450000 + 67500 + 10000);
  });

  it("no tax when tax is disabled", () => {
    const t = calculateTotals({ items, discount_type: "none", discount_value: 0, tax_enabled: false, tax_rate_bp: 1500, fees_cents: 0 });
    expect(t.tax_cents).toBe(0);
  });

  it("never produces a negative total from a large fixed discount", () => {
    const t = calculateTotals({ items, discount_type: "fixed", discount_value: 9_999_999, tax_enabled: true, tax_rate_bp: 1500, fees_cents: 0 });
    expect(t.discount_cents).toBe(500000);
    expect(t.total_cents).toBe(0);
  });

  it("avoids floating point drift on fractional quantities", () => {
    expect(lineTotal(0.1 * 3, 1000)).toBe(300);
    expect(lineTotal(2.5, 19999)).toBe(49998); // 499.975 rounds to 499.98
  });

  it("parses money input", () => {
    expect(parseMoneyToCents("3500")).toBe(350000);
    expect(parseMoneyToCents("R 1 234,50")).toBe(123450);
    expect(parseMoneyToCents("abc")).toBeNull();
  });
});
