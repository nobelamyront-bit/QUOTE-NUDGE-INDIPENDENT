import { queryOptions, useSuspenseQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getWorkspace } from './workspace.functions';
import { toast } from 'sonner';
export const workspaceOptions = queryOptions({ queryKey: ['workspace'], queryFn: () => getWorkspace(), staleTime: 20_000 });
export function useWorkspace() { return useSuspenseQuery(workspaceOptions).data; }
export function useAction<T, R>(action: (input: T) => Promise<R>, success?: string) {
  const client = useQueryClient();
  return useMutation({ mutationFn: action, onSuccess: async () => { await client.invalidateQueries({ queryKey: ['workspace'] }); if (success) toast.success(success); }, onError: (error) => toast.error(error instanceof Error ? error.message : 'Something went wrong') });
}
export const pageHead = (title: string, description: string) => ({ meta: [{ title: `${title} — QuoteNudge` }, { name: 'description', content: description }, { property: 'og:title', content: `${title} — QuoteNudge` }, { property: 'og:description', content: description }, { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary_large_image' }] });
export type Workspace = Awaited<ReturnType<typeof getWorkspace>>;
