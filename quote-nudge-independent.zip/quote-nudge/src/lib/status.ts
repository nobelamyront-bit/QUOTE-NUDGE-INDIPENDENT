export type QuoteStatus = "draft" | "pending" | "accepted" | "rejected" | "expired" | "cancelled";

export const STATUS_LABEL: Record<QuoteStatus, string> = {
  draft: "Draft",
  pending: "Pending",
  accepted: "Accepted",
  rejected: "Declined",
  expired: "Expired",
  cancelled: "Cancelled",
};

export const STATUS_CLASS: Record<QuoteStatus, string> = {
  draft: "bg-neutral-soft text-muted-foreground",
  pending: "bg-warning-soft text-warning",
  accepted: "bg-success-soft text-success",
  rejected: "bg-danger-soft text-destructive",
  expired: "bg-neutral-soft text-muted-foreground",
  cancelled: "bg-neutral-soft text-muted-foreground line-through",
};

/** Pending quotes past their validity date are shown as expired even before the DB catches up. */
export function effectiveStatus(status: QuoteStatus, validUntil: string, today: string): QuoteStatus {
  return status === "pending" && validUntil < today ? "expired" : status;
}

export const ALL_STATUSES: QuoteStatus[] = ["draft", "pending", "accepted", "rejected", "expired", "cancelled"];
