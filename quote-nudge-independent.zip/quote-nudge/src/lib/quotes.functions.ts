import { createServerFn } from "@tanstack/react-start";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { calculateTotals } from "./money";
import { addBusinessDays } from "./format";

const itemSchema = z.object({
  description: z.string().trim().min(1, "Item description is required").max(500),
  quantity: z.number().positive("Quantity must be greater than zero").max(1_000_000),
  unit_price_cents: z.number().int().min(0, "Unit price cannot be negative").max(10_000_000_000),
});

const optText = (max: number) => z.string().trim().max(max).optional().nullable().transform((v) => (v ? v : null));

const quoteSchema = z.object({
  id: z.string().uuid().optional().nullable(),
  customer_id: z.string().uuid({ message: "Choose a customer" }),
  title: z.string().trim().min(1, "Add a title").max(200),
  intro: optText(2000),
  issue_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  valid_until: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  currency: z.string().length(3),
  discount_type: z.enum(["none", "percent", "fixed"]),
  discount_value: z.number().int().min(0),
  tax_enabled: z.boolean(),
  tax_rate_bp: z.number().int().min(0).max(10000),
  tax_label: z.string().trim().min(1).max(30),
  fees_cents: z.number().int().min(0),
  fees_label: optText(80),
  payment_terms: optText(2000),
  deposit_info: optText(1000),
  payment_method: optText(200),
  terms: optText(5000),
  customer_notes: optText(3000),
  internal_notes: optText(3000),
  items: z.array(itemSchema).min(1, "Add at least one line item").max(100),
  finalize: z.boolean(),
});

export type SaveQuoteInput = z.input<typeof quoteSchema>;

function friendly(err: { message?: string } | null): never {
  const msg = err?.message ?? "Something went wrong";
  throw new Error(msg.replace(/^PLAN_LIMIT:\s*/, ""));
}

export const saveQuote = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: SaveQuoteInput) => quoteSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    if (data.valid_until < data.issue_date) throw new Error("Valid-until date must be on or after the issue date");
    if (data.discount_type === "percent" && data.discount_value > 10000) throw new Error("Discount cannot exceed 100%");

    const totals = calculateTotals(data);
    const { items, finalize, id, ...rest } = data;
    const row = {
      ...rest,
      subtotal_cents: totals.subtotal_cents,
      discount_cents: totals.discount_cents,
      tax_cents: totals.tax_cents,
      total_cents: totals.total_cents,
    };

    let quoteId = id ?? null;
    if (quoteId) {
      const { error } = await supabase.from("quotes").update(row).eq("id", quoteId);
      if (error) friendly(error);
      const { error: delErr } = await supabase.from("quote_items").delete().eq("quote_id", quoteId);
      if (delErr) friendly(delErr);
    } else {
      const { data: created, error } = await supabase
        .from("quotes")
        .insert({ ...row, owner_id: userId, number: "pending" })
        .select("id")
        .single();
      if (error) friendly(error);
      quoteId = created!.id;
    }

    const { error: itemErr } = await supabase.from("quote_items").insert(
      items.map((it, idx) => ({
        quote_id: quoteId!,
        owner_id: userId,
        position: idx,
        description: it.description,
        quantity: it.quantity,
        unit_price_cents: it.unit_price_cents,
        line_total_cents: totals.line_totals[idx] ?? 0,
      })),
    );
    if (itemErr) friendly(itemErr);

    if (finalize) await finalizeInternal(supabase, userId, quoteId!, data.customer_id);
    return { id: quoteId! };
  });

async function finalizeInternal(
  supabase: SupabaseClient<Database>,
  userId: string,
  quoteId: string,
  customerId: string,
) {
  const { error } = await supabase.from("quotes").update({ status: "pending" }).eq("id", quoteId).eq("status", "draft");
  if (error) friendly(error);
  const { data: biz } = await supabase.from("businesses").select("followup_delay_days").eq("owner_id", userId).maybeSingle();
  const when = addBusinessDays(new Date(), biz?.followup_delay_days ?? 2);
  when.setHours(9, 0, 0, 0);
  // Unique partial index prevents duplicate open follow-ups
  await supabase.from("follow_ups").insert({
    owner_id: userId,
    quote_id: quoteId,
    customer_id: customerId,
    scheduled_for: when.toISOString(),
    status: "scheduled",
  });
  await supabase.from("quote_events").insert({ owner_id: userId, quote_id: quoteId, type: "followup_scheduled", actor: "owner" });
}

export const finalizeQuote = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { data: q, error } = await context.supabase
      .from("quotes")
      .select("id, customer_id, status, valid_until, quote_items(count)")
      .eq("id", data.id)
      .single();
    if (error || !q) throw new Error("Quotation not found");
    if (q.status !== "draft") throw new Error("Only drafts can be finalized");
    const count = (q.quote_items as unknown as { count: number }[])[0]?.count ?? 0;
    if (count < 1) throw new Error("Add at least one line item before sharing");
    await finalizeInternal(context.supabase, context.userId, q.id, q.customer_id);
    return { ok: true };
  });

export const duplicateQuote = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: q, error } = await supabase.from("quotes").select("*, quote_items(*)").eq("id", data.id).single();
    if (error || !q) throw new Error("Quotation not found");
    const { data: biz } = await supabase.from("businesses").select("validity_days, timezone").eq("owner_id", userId).single();
    const today = new Intl.DateTimeFormat("en-CA", { timeZone: biz?.timezone ?? "Africa/Johannesburg" }).format(new Date());
    const until = new Date(today + "T00:00:00Z");
    until.setUTCDate(until.getUTCDate() + (biz?.validity_days ?? 14));
    const {
      id: _id, number: _n, status: _s, share_token: _t, created_at: _c, updated_at: _u, finalized_at: _f,
      responded_at: _r, response_message: _m, link_enabled: _l, quote_items, ...copy
    } = q;
    const { data: created, error: insErr } = await supabase
      .from("quotes")
      .insert({ ...copy, owner_id: userId, number: "pending", issue_date: today, valid_until: until.toISOString().slice(0, 10), replaces_id: q.id })
      .select("id")
      .single();
    if (insErr) friendly(insErr);
    const items = (quote_items as Array<{ position: number; description: string; quantity: number; unit_price_cents: number; line_total_cents: number }>)
      .sort((a, b) => a.position - b.position);
    if (items.length) {
      const { error: iErr } = await supabase.from("quote_items").insert(
        items.map((i) => ({ quote_id: created!.id, owner_id: userId, position: i.position, description: i.description, quantity: i.quantity, unit_price_cents: i.unit_price_cents, line_total_cents: i.line_total_cents })),
      );
      if (iErr) friendly(iErr);
    }
    await supabase.from("quote_events").insert({ owner_id: userId, quote_id: q.id, type: "duplicated", actor: "owner", metadata: { new_id: created!.id } });
    return { id: created!.id };
  });
