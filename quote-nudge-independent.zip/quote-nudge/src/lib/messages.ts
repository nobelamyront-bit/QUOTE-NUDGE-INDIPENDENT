import { formatDate } from "./format";

export type Tone = "friendly" | "professional" | "final";

export interface MessageContext {
  customerName: string;
  quoteNumber: string;
  title: string;
  issueDate: string;
  validUntil: string;
  total: string;
  link: string;
  businessName: string;
  ownerName?: string | undefined;
}

export function buildMessage(tone: Tone, c: MessageContext): string {
  const sign = c.ownerName ? `${c.ownerName}\n${c.businessName}` : c.businessName;
  const what = c.title ? ` for ${c.title}` : "";
  switch (tone) {
    case "friendly":
      return `Hi ${c.customerName}, I hope you're doing well. I just wanted to check whether you've had a chance to look over quotation ${c.quoteNumber}${what} (${c.total}). You can view it here:\n${c.link}\n\nHappy to answer any questions.\n\n${sign}`;
    case "professional":
      return `Good day ${c.customerName}. I'm following up on quotation ${c.quoteNumber}, issued on ${formatDate(c.issueDate)}${what}, totalling ${c.total}. Please let me know if you would like to proceed or if any changes are needed. The quotation is valid until ${formatDate(c.validUntil)}:\n${c.link}\n\nKind regards,\n${sign}`;
    case "final":
      return `Hi ${c.customerName}, I'm checking in one last time about quotation ${c.quoteNumber}${what}. Would you still like to go ahead? If your plans have changed, no problem at all — just let me know so I can close it off. The quotation is available here until ${formatDate(c.validUntil)}:\n${c.link}\n\nThank you,\n${sign}`;
  }
}

export function shareMessage(c: MessageContext): string {
  return `Hi ${c.customerName}, please find quotation ${c.quoteNumber}${c.title ? ` for ${c.title}` : ""} (${c.total}) here:\n${c.link}\n\nYou can accept or decline it directly on the page. It is valid until ${formatDate(c.validUntil)}.\n\n${c.businessName}`;
}

export function whatsappUrl(message: string, phoneDigits: string | null): string {
  const text = encodeURIComponent(message);
  return phoneDigits ? `https://wa.me/${phoneDigits}?text=${text}` : `https://wa.me/?text=${text}`;
}
