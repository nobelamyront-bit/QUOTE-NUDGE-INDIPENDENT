import { createFileRoute, useRouter } from '@tanstack/react-router';
import { useServerFn } from '@tanstack/react-start';
import { useState } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { getPublicQuote, respondPublicQuote } from '@/lib/workspace.functions';
import { formatMoney } from '@/lib/money';
import { formatDate } from '@/lib/format';
import { STATUS_LABEL, type QuoteStatus } from '@/lib/status';

type Item = { description: string; quantity: number; unit_price_cents: number; line_total_cents: number };
type PublicQuote = { unavailable?: boolean; business_name?: string; number: string; title: string; intro: string | null; status: QuoteStatus; issue_date: string; valid_until: string; currency: string; tax_enabled: boolean; tax_label: string; fees_cents: number; fees_label: string | null; subtotal_cents: number; discount_cents: number; tax_cents: number; total_cents: number; payment_terms: string | null; terms: string | null; customer_notes: string | null; customer: { name: string; company: string | null }; business: { name: string; email: string | null; phone: string | null; address: string | null; website: string | null; vat_number: string | null }; items: Item[] };

export const Route = createFileRoute('/q/$token')({
  loader: async ({ params }) => (await getPublicQuote({ data: { token: params.token } })) as unknown as PublicQuote | null,
  head: () => ({ meta: [{ title: 'Your quotation — QuoteNudge' }, { name: 'description', content: 'View and respond to your quotation.' }, { property: 'og:title', content: 'Your quotation' }, { property: 'og:description', content: 'View and respond to your quotation.' }, { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary' }, { name: 'robots', content: 'noindex' }] }),
  errorComponent: () => <div className="p-12 text-center">This quotation could not be loaded. Please try again.</div>,
  component: PublicQuotePage,
});

function PublicQuotePage() {
  const q = Route.useLoaderData();
  const { token } = Route.useParams();
  const router = useRouter();
  const respond = useServerFn(respondPublicQuote);
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  if (!q || q.unavailable) return <main className="mx-auto max-w-xl p-12 text-center"><h1 className="font-display text-2xl font-semibold">This quotation is not available</h1><p className="mt-2 text-muted-foreground">Please contact {q?.business_name ?? 'the business'} for an updated quotation.</p></main>;
  const m = (c: number) => formatMoney(c, q.currency);
  const decide = async (decision: 'accepted' | 'rejected') => {
    setBusy(true);
    try { const r = (await respond({ data: { token, decision, message } })) as { ok: boolean; reason?: string }; if (r.ok) toast.success(decision === 'accepted' ? 'Thank you — your acceptance was recorded.' : 'Your response was recorded.'); else toast.error(r.reason === 'expired' ? 'This quotation has expired.' : 'This quotation can no longer be changed.'); await router.invalidate(); }
    catch (e) { toast.error(e instanceof Error ? e.message : 'Please try again.'); } finally { setBusy(false); }
  };
  return <main className="mx-auto max-w-3xl px-5 py-12">
    <header className="mb-10 flex flex-wrap justify-between gap-4 border-b pb-6"><div><p className="font-display text-2xl font-semibold">{q.business.name}</p><p className="text-sm text-muted-foreground">{[q.business.phone, q.business.email, q.business.website].filter(Boolean).join(' · ')}</p>{q.business.address && <p className="text-sm text-muted-foreground">{q.business.address}</p>}{q.business.vat_number && <p className="text-xs text-muted-foreground">VAT {q.business.vat_number}</p>}</div><div className="text-right text-sm"><p className="font-semibold">Quotation {q.number}</p><p>Issued {formatDate(q.issue_date)}</p><p>Valid until {formatDate(q.valid_until)}</p><p className="mt-1 font-semibold">{STATUS_LABEL[q.status]}</p></div></header>
    <p className="text-sm text-muted-foreground">Prepared for {q.customer.name}{q.customer.company ? `, ${q.customer.company}` : ''}</p>
    <h1 className="mb-4 mt-1 font-display text-3xl font-semibold">{q.title}</h1>
    {q.intro && <p className="mb-6 whitespace-pre-wrap">{q.intro}</p>}
    <table className="mb-6 w-full text-sm"><thead><tr className="border-b text-left text-xs uppercase text-muted-foreground"><th className="py-2">Item</th><th>Qty</th><th className="text-right">Price</th><th className="text-right">Total</th></tr></thead><tbody>{q.items.map((i, k) => <tr key={k} className="border-b"><td className="py-3">{i.description}</td><td>{i.quantity}</td><td className="text-right">{m(i.unit_price_cents)}</td><td className="text-right">{m(i.line_total_cents)}</td></tr>)}</tbody></table>
    <dl className="mb-8 ml-auto max-w-xs space-y-1 text-sm"><div className="flex justify-between"><dt>Subtotal</dt><dd>{m(q.subtotal_cents)}</dd></div>{q.discount_cents > 0 && <div className="flex justify-between"><dt>Discount</dt><dd>−{m(q.discount_cents)}</dd></div>}{q.tax_enabled && <div className="flex justify-between"><dt>{q.tax_label}</dt><dd>{m(q.tax_cents)}</dd></div>}{q.fees_cents > 0 && <div className="flex justify-between"><dt>{q.fees_label || 'Fees'}</dt><dd>{m(q.fees_cents)}</dd></div>}<div className="flex justify-between border-t pt-2 text-lg font-semibold"><dt>Total</dt><dd>{m(q.total_cents)}</dd></div></dl>
    {[['Payment terms', q.payment_terms], ['Notes', q.customer_notes], ['Terms & conditions', q.terms]].map(([l, v]) => v && <section key={l} className="mb-4 text-sm"><h2 className="font-semibold">{l}</h2><p className="whitespace-pre-wrap text-muted-foreground">{v}</p></section>)}
    {q.status === 'pending' && <section className="mt-10 rounded-lg border bg-card p-5"><h2 className="mb-2 font-semibold">Your decision</h2><Textarea value={message} maxLength={1000} onChange={e => setMessage(e.target.value)} placeholder="Optional message for the business"/><div className="mt-3 flex gap-2"><Button disabled={busy} onClick={() => decide('accepted')}>Accept quotation</Button><Button variant="outline" disabled={busy} onClick={() => decide('rejected')}>Decline</Button></div></section>}
  </main>;
}
