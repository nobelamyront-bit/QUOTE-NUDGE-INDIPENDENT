import { createFileRoute, useNavigate } from '@tanstack/react-router';
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { pageHead } from '@/lib/workspace';
export const Route=createFileRoute('/reset-password')({head:()=>pageHead('Reset password','Choose a new secure password for your QuoteNudge account.'),component:Reset});
function Reset(){const [password,setPassword]=useState('');const [message,setMessage]=useState('');const [busy,setBusy]=useState(false);const navigate=useNavigate();return <main className="mx-auto max-w-sm px-5 py-24"><h1 className="mb-8 text-2xl font-semibold">Choose a new password</h1><form className="space-y-5" onSubmit={async e=>{e.preventDefault();setBusy(true);const {error}=await supabase.auth.updateUser({password});setBusy(false);if(error)setMessage(error.message);else await navigate({to:'/dashboard'});}}><label className="text-sm">New password<input type="password" required minLength={6} autoComplete="new-password" className="field mt-2" value={password} onChange={e=>setPassword(e.target.value)}/></label>{message&&<p role="alert">{message}</p>}<Button disabled={busy}>Save password</Button></form></main>;}
