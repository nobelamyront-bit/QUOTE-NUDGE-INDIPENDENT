import { createFileRoute } from '@tanstack/react-router';
import { QuoteDetail } from '@/components/workspace/QuoteDetail';
import { pageHead } from '@/lib/workspace';
export const Route = createFileRoute('/_authenticated/quotes/$id')({ head: () => pageHead('Quotation', 'Quotation details, sharing and activity.'), component: QuotePage });
function QuotePage() { const { id } = Route.useParams(); return <QuoteDetail key={id} id={id}/>; }
