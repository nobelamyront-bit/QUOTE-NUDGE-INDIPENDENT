import { createFileRoute } from '@tanstack/react-router';
import { QuoteEditor } from '@/components/workspace/QuoteEditor';
import { pageHead } from '@/lib/workspace';
export const Route = createFileRoute('/_authenticated/quotes/new')({ head: () => pageHead('New quotation', 'Create a professional quotation in minutes.'), component: NewQuote });
function NewQuote() { return <QuoteEditor/>; }
