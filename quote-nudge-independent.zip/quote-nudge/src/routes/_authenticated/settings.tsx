import { createFileRoute } from '@tanstack/react-router';
import { Settings } from '@/components/workspace/Settings';
import { pageHead } from '@/lib/workspace';
export const Route=createFileRoute('/_authenticated/settings')({head:()=>pageHead('Business settings','Your business profile, quotation defaults and preferences.'),component:Settings});
