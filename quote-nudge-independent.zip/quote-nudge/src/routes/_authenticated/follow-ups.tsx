import { createFileRoute } from '@tanstack/react-router';
import { FollowUps } from '@/components/workspace/FollowUps';
import { pageHead } from '@/lib/workspace';
export const Route = createFileRoute('/_authenticated/follow-ups')({ head: () => pageHead('Follow-ups', 'Prepared follow-up messages for quotations awaiting a decision.'), component: FollowUps });
