import { createFileRoute } from '@tanstack/react-router';
import { Reports } from '@/components/workspace/Reports';
import { pageHead } from '@/lib/workspace';
export const Route = createFileRoute('/_authenticated/reports')({ head: () => pageHead('Reports', 'Win rate, won value and quotations awaiting a decision.'), component: Reports });
