import { createFileRoute } from '@tanstack/react-router';
import { Customers } from '@/components/workspace/Customers';
import { pageHead } from '@/lib/workspace';
export const Route=createFileRoute('/_authenticated/customers')({validateSearch:(s:Record<string,unknown>)=>({search:typeof s['search']==='string'?s['search']:''}),head:()=>pageHead('Customers','Manage your customers and their contact details.'),component:Customers});
