import { createFileRoute, redirect } from '@tanstack/react-router';
import { supabase } from '@/integrations/supabase/client';
import { workspaceOptions } from '@/lib/workspace';
import { Shell } from '@/components/workspace/Shell';
import { PageError, Missing } from '@/components/workspace/shared';
export const Route = createFileRoute('/_authenticated')({ ssr: false, beforeLoad: async () => { const { data, error } = await supabase.auth.getUser(); if (error || !data.user) throw redirect({ to: '/auth' }); }, loader: async ({ context }) => { await context.queryClient.ensureQueryData(workspaceOptions); }, component: Shell, errorComponent: PageError, notFoundComponent: Missing });
