import { createFileRoute } from '@tanstack/react-router';
import { Quotes } from '@/components/workspace/Quotes';
import { pageHead } from '@/lib/workspace';
export const Route = createFileRoute('/_authenticated/quotes/')({ validateSearch:(s:Record<string,unknown>)=>({search:typeof s['search']==='string'?s['search']:'',status:typeof s['status']==='string'?s['status']:''}),head:()=>pageHead('Quotations','Manage professional quotations and track every customer response.'), component:Quotes });
