import { createFileRoute } from '@tanstack/react-router';
import { Dashboard } from '@/components/workspace/Dashboard';
import { pageHead } from '@/lib/workspace';
export const Route = createFileRoute('/_authenticated/dashboard')({ head:()=>pageHead('Overview','Your quotations, customer responses and follow-ups at a glance.'), component:Dashboard });
