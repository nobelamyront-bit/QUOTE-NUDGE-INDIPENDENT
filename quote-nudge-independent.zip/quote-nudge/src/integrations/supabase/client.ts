// CHANGED: Browser + SSR Supabase client. This file is now maintained by hand (it was previously
// produced by a code generator). Removed: the iframe "session broker" storage and the server-URL
// rewriting that only made sense on the old hosting platform. Sessions now use the standard
// localStorage that supabase-js manages for you.
import { createClient } from '@supabase/supabase-js';
import type { Database } from './types';

function isNewSupabaseApiKey(value: string): boolean {
  return value.startsWith('sb_publishable_') || value.startsWith('sb_secret_');
}

function createSupabaseFetch(supabaseKey: string): typeof fetch {
  return (input, init) => {
    const headers = new Headers(
      typeof Request !== 'undefined' && input instanceof Request ? input.headers : undefined,
    );

    if (init?.headers) {
      new Headers(init.headers).forEach((value, key) => headers.set(key, value));
    }

    // New-style Supabase API keys (sb_publishable_... / sb_secret_...) are opaque strings, not
    // JWTs, so they must never be sent as a Bearer token. Strip it and send them as `apikey` only.
    if (isNewSupabaseApiKey(supabaseKey) && headers.get('Authorization') === `Bearer ${supabaseKey}`) {
      headers.delete('Authorization');
    }

    headers.set('apikey', supabaseKey);
    return fetch(input, { ...init, headers });
  };
}

function createSupabaseClient() {
  // ACTION REQUIRED: provide these two values from YOUR new Supabase project
  //   (Supabase dashboard -> Project Settings -> API / API Keys):
  //   - Local development: put them in `.env.local` (see .env.example).
  //   - Production: add them in Netlify -> Site configuration -> Environment variables.
  // VITE_* values are inlined into the browser bundle at BUILD time, so changing them in Netlify
  // requires a new deploy. The URL and publishable key are designed to be public; never put a
  // service-role / secret key in a VITE_* variable.
  // The process.env fallback only applies on the server (SSR) when a VITE_* value is absent.
  const SUPABASE_URL =
    import.meta.env['VITE_SUPABASE_URL'] ||
    (typeof process !== 'undefined' ? process.env['SUPABASE_URL'] : undefined);
  const SUPABASE_PUBLISHABLE_KEY =
    import.meta.env['VITE_SUPABASE_PUBLISHABLE_KEY'] ||
    (typeof process !== 'undefined' ? process.env['SUPABASE_PUBLISHABLE_KEY'] : undefined);

  if (!SUPABASE_URL || !SUPABASE_PUBLISHABLE_KEY) {
    const missing = [
      ...(!SUPABASE_URL ? ['VITE_SUPABASE_URL'] : []),
      ...(!SUPABASE_PUBLISHABLE_KEY ? ['VITE_SUPABASE_PUBLISHABLE_KEY'] : []),
    ];
    // CHANGED: error message now points at your own configuration instead of a hosted dashboard.
    const message = `Missing Supabase environment variable(s): ${missing.join(', ')}. Copy .env.example to .env.local (local) or set them in the Netlify dashboard (production).`;
    console.error(`[Supabase] ${message}`);
    throw new Error(message);
  }

  return createClient<Database>(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
    global: {
      fetch: createSupabaseFetch(SUPABASE_PUBLISHABLE_KEY),
    },
    auth: {
      // CHANGED: `storage` option removed -> supabase-js default (localStorage in the browser).
      persistSession: true,
      autoRefreshToken: true,
    },
  });
}

let _supabase: ReturnType<typeof createSupabaseClient> | undefined;

// Import the supabase client like this:
// import { supabase } from "@/integrations/supabase/client";
// (Created lazily on first use so a missing env var fails with a clear message.)
export const supabase = new Proxy({} as ReturnType<typeof createSupabaseClient>, {
  get(_, prop, receiver) {
    if (!_supabase) _supabase = createSupabaseClient();
    return Reflect.get(_supabase, prop, receiver);
  },
});
