export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      businesses: {
        Row: {
          address: string | null
          business_type: string | null
          country: string
          created_at: string
          currency: string
          default_payment_terms: string | null
          default_terms: string | null
          email: string | null
          followup_delay_days: number
          id: string
          locale: string
          logo_url: string | null
          name: string
          onboarded: boolean
          owner_id: string
          owner_name: string
          phone: string | null
          plan: string
          quote_seq: number
          registration_number: string | null
          tax_enabled: boolean
          tax_label: string
          tax_rate_bp: number
          timezone: string
          updated_at: string
          validity_days: number
          vat_number: string | null
          website: string | null
        }
        Insert: {
          address?: string | null
          business_type?: string | null
          country?: string
          created_at?: string
          currency?: string
          default_payment_terms?: string | null
          default_terms?: string | null
          email?: string | null
          followup_delay_days?: number
          id?: string
          locale?: string
          logo_url?: string | null
          name?: string
          onboarded?: boolean
          owner_id: string
          owner_name?: string
          phone?: string | null
          plan?: string
          quote_seq?: number
          registration_number?: string | null
          tax_enabled?: boolean
          tax_label?: string
          tax_rate_bp?: number
          timezone?: string
          updated_at?: string
          validity_days?: number
          vat_number?: string | null
          website?: string | null
        }
        Update: {
          address?: string | null
          business_type?: string | null
          country?: string
          created_at?: string
          currency?: string
          default_payment_terms?: string | null
          default_terms?: string | null
          email?: string | null
          followup_delay_days?: number
          id?: string
          locale?: string
          logo_url?: string | null
          name?: string
          onboarded?: boolean
          owner_id?: string
          owner_name?: string
          phone?: string | null
          plan?: string
          quote_seq?: number
          registration_number?: string | null
          tax_enabled?: boolean
          tax_label?: string
          tax_rate_bp?: number
          timezone?: string
          updated_at?: string
          validity_days?: number
          vat_number?: string | null
          website?: string | null
        }
        Relationships: []
      }
      customers: {
        Row: {
          billing_address: string | null
          company: string | null
          created_at: string
          email: string | null
          id: string
          name: string
          notes: string | null
          owner_id: string
          phone: string | null
          updated_at: string
        }
        Insert: {
          billing_address?: string | null
          company?: string | null
          created_at?: string
          email?: string | null
          id?: string
          name: string
          notes?: string | null
          owner_id?: string
          phone?: string | null
          updated_at?: string
        }
        Update: {
          billing_address?: string | null
          company?: string | null
          created_at?: string
          email?: string | null
          id?: string
          name?: string
          notes?: string | null
          owner_id?: string
          phone?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      follow_ups: {
        Row: {
          channel: string | null
          completed_at: string | null
          created_at: string
          customer_id: string
          id: string
          message: string | null
          outcome: string | null
          owner_id: string
          quote_id: string
          scheduled_for: string | null
          status: string
        }
        Insert: {
          channel?: string | null
          completed_at?: string | null
          created_at?: string
          customer_id: string
          id?: string
          message?: string | null
          outcome?: string | null
          owner_id?: string
          quote_id: string
          scheduled_for?: string | null
          status?: string
        }
        Update: {
          channel?: string | null
          completed_at?: string | null
          created_at?: string
          customer_id?: string
          id?: string
          message?: string | null
          outcome?: string | null
          owner_id?: string
          quote_id?: string
          scheduled_for?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "follow_ups_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "follow_ups_quote_id_fkey"
            columns: ["quote_id"]
            isOneToOne: false
            referencedRelation: "quotes"
            referencedColumns: ["id"]
          },
        ]
      }
      quote_events: {
        Row: {
          actor: string
          created_at: string
          id: string
          metadata: Json
          owner_id: string
          quote_id: string
          type: string
        }
        Insert: {
          actor?: string
          created_at?: string
          id?: string
          metadata?: Json
          owner_id: string
          quote_id: string
          type: string
        }
        Update: {
          actor?: string
          created_at?: string
          id?: string
          metadata?: Json
          owner_id?: string
          quote_id?: string
          type?: string
        }
        Relationships: [
          {
            foreignKeyName: "quote_events_quote_id_fkey"
            columns: ["quote_id"]
            isOneToOne: false
            referencedRelation: "quotes"
            referencedColumns: ["id"]
          },
        ]
      }
      quote_items: {
        Row: {
          description: string
          id: string
          line_total_cents: number
          owner_id: string
          position: number
          quantity: number
          quote_id: string
          unit_price_cents: number
        }
        Insert: {
          description: string
          id?: string
          line_total_cents: number
          owner_id?: string
          position?: number
          quantity: number
          quote_id: string
          unit_price_cents: number
        }
        Update: {
          description?: string
          id?: string
          line_total_cents?: number
          owner_id?: string
          position?: number
          quantity?: number
          quote_id?: string
          unit_price_cents?: number
        }
        Relationships: [
          {
            foreignKeyName: "quote_items_quote_id_fkey"
            columns: ["quote_id"]
            isOneToOne: false
            referencedRelation: "quotes"
            referencedColumns: ["id"]
          },
        ]
      }
      quotes: {
        Row: {
          created_at: string
          currency: string
          customer_id: string
          customer_notes: string | null
          deposit_info: string | null
          discount_cents: number
          discount_type: string
          discount_value: number
          fees_cents: number
          fees_label: string | null
          finalized_at: string | null
          id: string
          internal_notes: string | null
          intro: string | null
          issue_date: string
          link_enabled: boolean
          number: string
          owner_id: string
          payment_method: string | null
          payment_terms: string | null
          replaces_id: string | null
          responded_at: string | null
          response_message: string | null
          share_token: string | null
          status: Database["public"]["Enums"]["quote_status"]
          subtotal_cents: number
          tax_cents: number
          tax_enabled: boolean
          tax_label: string
          tax_rate_bp: number
          terms: string | null
          title: string
          total_cents: number
          updated_at: string
          valid_until: string
        }
        Insert: {
          created_at?: string
          currency?: string
          customer_id: string
          customer_notes?: string | null
          deposit_info?: string | null
          discount_cents?: number
          discount_type?: string
          discount_value?: number
          fees_cents?: number
          fees_label?: string | null
          finalized_at?: string | null
          id?: string
          internal_notes?: string | null
          intro?: string | null
          issue_date?: string
          link_enabled?: boolean
          number: string
          owner_id?: string
          payment_method?: string | null
          payment_terms?: string | null
          replaces_id?: string | null
          responded_at?: string | null
          response_message?: string | null
          share_token?: string | null
          status?: Database["public"]["Enums"]["quote_status"]
          subtotal_cents?: number
          tax_cents?: number
          tax_enabled?: boolean
          tax_label?: string
          tax_rate_bp?: number
          terms?: string | null
          title?: string
          total_cents?: number
          updated_at?: string
          valid_until?: string
        }
        Update: {
          created_at?: string
          currency?: string
          customer_id?: string
          customer_notes?: string | null
          deposit_info?: string | null
          discount_cents?: number
          discount_type?: string
          discount_value?: number
          fees_cents?: number
          fees_label?: string | null
          finalized_at?: string | null
          id?: string
          internal_notes?: string | null
          intro?: string | null
          issue_date?: string
          link_enabled?: boolean
          number?: string
          owner_id?: string
          payment_method?: string | null
          payment_terms?: string | null
          replaces_id?: string | null
          responded_at?: string | null
          response_message?: string | null
          share_token?: string | null
          status?: Database["public"]["Enums"]["quote_status"]
          subtotal_cents?: number
          tax_cents?: number
          tax_enabled?: boolean
          tax_label?: string
          tax_rate_bp?: number
          terms?: string | null
          title?: string
          total_cents?: number
          updated_at?: string
          valid_until?: string
        }
        Relationships: [
          {
            foreignKeyName: "quotes_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "quotes_replaces_id_fkey"
            columns: ["replaces_id"]
            isOneToOne: false
            referencedRelation: "quotes"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      expire_my_quotes: { Args: never; Returns: number }
      get_public_quote: { Args: { _token: string }; Returns: Json }
      respond_to_quote: {
        Args: { _decision: string; _message: string; _token: string }
        Returns: Json
      }
    }
    Enums: {
      quote_status:
        | "draft"
        | "pending"
        | "accepted"
        | "rejected"
        | "expired"
        | "cancelled"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      quote_status: [
        "draft",
        "pending",
        "accepted",
        "rejected",
        "expired",
        "cancelled",
      ],
    },
  },
} as const
