// CHANGED: This file used to re-export a vendor-managed Vite preset that silently injected a set of
// plugins behind the scenes (TanStack Start, React, Tailwind, tsconfig paths, a Nitro build that
// targeted Cloudflare, env injection, an error-logger and sandbox/port detection).
// Those plugins are now listed explicitly below, so the build is transparent and targets Netlify.
//
// NOTE on removed pieces:
//  - Nitro / Cloudflare target: replaced by the official Netlify adapter plugin (`netlify()` below).
//  - `server: { entry: "server" }` + src/server.ts: that was an SSR error wrapper written for the
//    Nitro (h3) pipeline. TanStack Start's default server entry is used instead; errors are still
//    handled by the middleware in src/start.ts and the error components in src/routes/__root.tsx.
//  - VITE_* env injection: built into Vite itself. Put VITE_* values in `.env.local` for local
//    development and in the Netlify dashboard for production (see .env.example).
//  - "@" path alias: provided by `vite-tsconfig-paths` reading the "paths" block in tsconfig.json.
import { defineConfig } from "vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import netlify from "@netlify/vite-plugin-tanstack-start";
import viteReact from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import tsConfigPaths from "vite-tsconfig-paths";

export default defineConfig({
  plugins: [
    tsConfigPaths(), // resolves the "@/..." imports declared in tsconfig.json
    tanstackStart(), // TanStack Start (SSR + server functions + file-based routing)
    netlify(), // ADDED: builds the SSR output as Netlify Functions + emulates Netlify in `vite dev`
    viteReact(), // must come after tanstackStart()
    tailwindcss(), // Tailwind CSS v4
  ],
  resolve: {
    // Guards against duplicate copies of these packages ending up in the bundle.
    dedupe: ["react", "react-dom", "@tanstack/react-router", "@tanstack/react-start"],
  },
});
