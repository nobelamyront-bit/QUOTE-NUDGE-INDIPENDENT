# QuoteNudge MVP
- [x] Public home and account sign-in
- [x] Dark mode
- [x] Business setup and settings
- [x] Dashboard, customer management and reports
- [x] Quotation editor, sharing and public decisions
- [x] Follow-up scheduling and WhatsApp messages
- [x] Verify real account workflow and existing tests